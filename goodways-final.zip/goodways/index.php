<?php

// establish the database connection

require('includes/common.php');

// if user logged in 
if(isset($_SESSION['email'])){

	// go to home page  
	header('location: home.php');
	exit();
}

// include the heaader which contains navbar

include('includes/header.php');
 
?>


<style type="text/css">
    
    .form-control { margin-bottom: 10px;}
    body { background:url("images/goodways_fitness.jpg"); }

</style>

<div class="container">
    <div class="row">
        <div class="col-lg-4 col-md-4"></div>
        <div class=" col-lg-4 col-xs-12 col-sm-12 col-md-4 well well-sm">
            
            <legend>
                <a href="http://www.jquery2dotnet.com">
                    <i class="glyphicon glyphicon-globe"></i>
                </a>
                Sign up!
            </legend>
            
            <form action="php_scripts/register_new.php" method="post" class="form" role="form">
                <div class="row">
                    
                    <div class="col-xs-6">
                        <input class="form-control" name="name" 
                        placeholder="Name" type="text" required autofocus required/>
                    </div>

                    <div class="col-xs-6">
                        <input class="form-control" name="phone" 
                        placeholder="Phone Number" type="text" required/>
                    </div>
                </div>
                <div class="row" >
                    <div class="col-xs-12">
                        <input class="form-control" name="address" placeholder="Address" type="text"    required/>
                    </div>
                </div>
                
                <div class="row" >
                    <div class="col-xs-6">
                        <input class="form-control" id="email_id" name="email" 
                        placeholder="Your Email" type="email" required />
                    </div>
                    <div class="col-xs-4">
                       <h6><b id="chk_available">Check Availability</b></h6>
                    </div>
                    <div class="col-xs-2">
                        <a class="btn btn-sm glyphicon glyphicon-refresh  
                        btn-success " onclick="is_email_available()">
                        </a>
                    </div>
                    
                </div>

                <input class="form-control" name="password" placeholder="New Password" type="password" required />
                <input class="form-control" name="reenterpass" placeholder="Re-enter Password" type="password" required />
                
                <div class="row" >
                    <div class="col-xs-4 col-md-4">
                        <b> Birth Date : </b>
                    </div>
                    <div class="col-xs-8 col-md-8">
                       <input class="form-control" type="date" 
                       name="date_of_birth" value="1990-01-01">
                    </div>
                </div>

                <div class="row" >
                    <div class="col-xs-4">
                        <b>Gender : </b>
                    </div>
                    <div class="col-xs-4">
                        <label class="radio-inline">
                            <input type="radio" name="gender" 
                            value="male" /> Male
                        </label>
                    </div>
                    <div class="col-xs-4">
                        <label class="radio-inline">
                            <input type="radio" name="gender" 
                            value="female" checked/> Female
                        </label>
                    </div>
                </div>
                <br>                
                <div class="row">
                    <div class="col-xs-4">
                        <b>Blood Group : </b>
                    </div>
                    <div class="col-xs-8"> 
                        <select name="blood_group" class="form-control">
                            <option value="O-positive">O-positive</option>
                            <option value="O-negative">O-negative</option>
                            <option value="A-positive">A-positive</option>
                            <option value="A-negative">A-negative</option>
                            <option value="B-positive">B-positive</option>
                            <option value="B-negative">B-negative</option>
                            <option value="AB-positive">AB-positive</option>
                            <option value="AB-negative">AB-negative</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-4">
                        <b>Position : </b>
                    </div>
                    <div class="col-xs-8"> 
                        <select name="position" class="form-control">
                            <option value="Member">Member</option>
                            <option value="Trainer">Trainer</option>
                            <option value="Receptionist">Receptionist</option>
                            <option value="Employee">Employee</option>
                            <option value="Incharge">Incharge</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-4"> 
                        <b>User Type : </b>
                    </div>
                    <div class="col-xs-4"> 
                        <label class="radio-inline">
                            <input type="radio" name="user_type" 
                            id="user_type_member" value="Member"
                            onclick="disable_verification()"
                             checked/>
                            Member
                        </label>
                    </div>
                    <div class="col-xs-4">     
                        <label class="radio-inline">
                            <input type="radio" name="user_type" 
                            id="user_type_admin" value="Admin" 
                            onclick="create_verification()"  
                            />
                            Admin
                        </label>
                    </div>    
                </div>
                <br>
                <div id="hint_text"></div>                
                <div id="passkey_enable"></div>
                

                
                <button class="btn btn-md btn-primary btn-block" 
                onclick="return confirm_password_signup()" name="register_new" type="submit">
                    Sign up</button>
            </form>
        </div>
        <div class="col-lg-4 col-md-4"></div>
    </div>
</div>


<script type="text/javascript" src="ajax_js/is_email_available.js" ></script>

<script type="text/javascript">
    
    var text = "<div class=\"row\" >"+"<div class=\"col-xs-4 col-md-4\">"+
               "<b> Verification Passkey : </b></div>"+
               "<div class=\"col-xs-8 col-md-8\">"+
               "<input class=\"form-control\" type=\"password\" "+ 
               "name=\"verification\" placeholder=\"passkey to become admin\" required>"+
               "</div></div>";

    function create_verification() {
        document.getElementById('passkey_enable').innerHTML = text;
    }

    function disable_verification() {
        document.getElementById('passkey_enable').innerHTML = "";
    }



</script>

<?php

include('includes/footer.php');

?>
