<?php

include('includes/common.php');
include('includes/is_auth.php');
include('includes/header.php');

// get the id from session variable

$uid = $_SESSION['id'];

// fetch the all data of the personal details of user in $user_details variable

$name = "";
$Isadmin = $_SESSION['Isadmin'];


if($Isadmin == true){

    // personal details


    $query = "SELECT * from admin_users WHERE admin_id = $uid";
    $user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
    $user_details = mysqli_fetch_array($user_query);
    
    $name = $user_details['admin_name'];
    $gender = $_SESSION['gender'] = $user_details['gender'];
    $email = $user_details['admin_email'];
    $phone_number = $user_details['phone_number'];
    $address = $user_details['address'];
    $blood_group = $user_details['blood_group'];
    $date_of_birth = date_format(date_create($user_details['date_of_birth']), 'd-m-Y');


    $fee_form_enable = false;
	
    }else {

    // personal details

    $query = "SELECT * from member_users WHERE member_id = $uid";
    $user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
    $user_details = mysqli_fetch_array($user_query);
    
    $name = $user_details['member_name'];
    $gender = $_SESSION['gender'] = $user_details['gender'];
    $email = $user_details['email'];
    $phone_number = $user_details['phone_number'];
    $address = $user_details['address'];
    $blood_group = $user_details['blood_group'];
    $date_of_birth = date_format(date_create($user_details['date_of_birth']), 'd-m-Y');


    // User Fee Payment - letest

    $query = "SELECT * from my_fee where member_id = $uid and status = 1
    order by expire_datetime desc";

    $user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));

    $row = mysqli_fetch_array($user_query);

    $requested_datetime = $row['requested_datetime'];
    $confirmed_datetime = $row['confirmed_datetime'];

    $balance_paid = $row['balance_paid'];
    $balance_remaining = $row['balance_remaining'];
    $package = $row['package'];


    // Fee Form 

    $fee_form_enable = true;

    $expire_datetime = $row['expire_datetime'];
    $current_datetime =  date('Y-m-d H:i:s');

    if($expire_datetime > $current_datetime){
        $fee_form_enable = false;
    }
 

    $first_fee = "SELECT * from my_fee where member_id = '$uid' and status = '1' ORDER BY confirmed_datetime DESC";
    $first_fee = mysqli_query($conn, $first_fee) or die(mysqli_error($conn));

    if(mysqli_num_rows($first_fee) == 0){
      $discount_granted = true; 
      $discount_factor = 1;
    }else{
      $discount_granted = false;
    }

}

?>


<style type="text/css">
    body{
        margin-top:80px;
    }
</style>


<!-- Personal Details -->
<div class="container">
        <div class="row">
            <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">
                
            <?php 

                $profile_image = $user_details['profile_pic'];
                
                echo '<img src="data:image;base64,'.$profile_image.' " 
                width="250" height="250" alt="profile pic" class="img thumbnail" >';
            
            ?>
            <form action="php_scripts/update_profile_pic.php" method="post" enctype="multipart/form-data">
                <input type="file" class="btn btn-sm" name="file_profile_image" id="fileToUpload">
                <input type="submit" class="btn-success btn btn-sm" value="Update Profile Pic" name="update_submit">  
                <input type="submit" class="btn-danger btn btn-sm" value="Delete Pic" name="delete_submit">  

            </form>  
                <br>

            </div>
            <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8">
                <div class="container" >
                    <h2 ><p id="pd_name"> <?php echo $name; ?>
                    <a class="btn btn-sm glyphicon glyphicon-edit" onclick="edit_details('pd_name','name',<?php echo "'".$name."'"; ?>)">edit</a></p></h2>
                </div>
                <hr>
                <ul class="container details">
                    <li>
                        <p>
                            <span class="glyphicon glyphicon-envelope one" style="width:50px;"></span><?php echo $email; ?>
                        </p>
                    </li>
                    <li>
                        <p id="pd_gender">
                            <?php
                            $icon ="";

                            if($gender == "female"){
                                $icon = "<span class=\"fa fa-female\" style=\"width:50px;\"></span>";
                            }else if ($gender == "male"){
                                $icon = "<span class=\"fa fa-male\" style=\"width:50px;\"></span>";
                            }
                            echo $icon.$gender."";

                            ?> 
                        <a class="btn btn-sm glyphicon glyphicon-edit" 
                        onclick="edit_details('pd_gender','gender',<?php echo "'".$gender."'"; ?>)">edit</a>
                        </p>
                    </li>

                <li>
                    <p>
                        <span id="pd_phone">
                            <span class="glyphicon glyphicon-earphone one" style="width:50px;"></span>
                            <?php echo $phone_number; ?> 
                            <a class="btn btn-sm glyphicon glyphicon-edit" onclick="edit_details('pd_phone','phone_number',<?php echo "'".$phone_number."'"; ?>)">edit</a>
                            </span>
                        </p>
                    </p>
                </li>
                <li>
                    <p id="pd_address">
                        <span class="fa fa-building" style="width:50px;"></span>
                        <?php echo $address; ?> 
                        <a class="btn btn-sm glyphicon glyphicon-edit" onclick="edit_details('pd_address','address',<?php echo "'".$address."'"; ?>)">edit</a>
                    </p>
                </li>
                
                <li>
                    <p id="pd_blood_group">
                    <span class="glyphicon glyphicon glyphicon-tint" style="width:50px;">
                    </span><?php echo $blood_group; ?> 
                    <a onclick="edit_details('pd_blood_group','blood_group',<?php echo "'".$blood_group."'"; ?>)"
                    class="btn btn-sm glyphicon glyphicon-edit">edit</a>
                    </p>
                </li>
                <li>
                    <p id="pd_date_of_birth">
                    <span class="glyphicon  glyphicon-calendar" style="width:50px;"></span>
                    <?php echo $date_of_birth; 
                    // reversing the order to set the default argument "y-m-d"
                    $date_of_birth_reverse_format = date_format(date_create($user_details['date_of_birth']), 'Y-m-d'); 
                    $date_of_birth_reverse_format = (string)($date_of_birth_reverse_format);
                    ?> 
                    <a onclick="edit_details('pd_date_of_birth','date_of_birth',<?php echo "'".$date_of_birth_reverse_format."'"; ?>)" class="btn btn-sm glyphicon glyphicon-edit">edit</a>
                    </p>
                </li>
                </ul>
            </div>
    </div>
</div>



<script type="text/javascript" src="ajax_js/edit_user_details.js">
</script>

<!-- end of personal details -->
<br><br><br>

<?php if($_SESSION['Isadmin'] == false){ ?>

<!-- Pay fee -->


<div class="container">
    <div class="row">

        <div class="col-md-12 text-center">
            <h3> Fee Payment </h3><br>
            <h4> 
            <?php 
                if($discount_granted){
                    // echo "Get 10% discount on first fee";
                } 
            ?>

            </h4><br>
                        
            <?php if($fee_form_enable == true){ ?>

            <form class="form-horizontal well" method="post" action="php_scripts/pay_fee.php" role="form">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <img src="#" height="200" ><br>
                        <input type="radio" name="package" onclick="set_fee_amount()" value="1 Month" checked> 1 Month
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <img src="#" height="200" ><br>

                        <input type="radio" name="package" onclick="set_fee_amount()" value="4 Months"> 4 Months
                        
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <img src="#" height="200" ><br>

                        <input type="radio" name="package" onclick="set_fee_amount()" value="6 Months"> 6 Months
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <img src="#" height="200" ><br>

                        <input type="radio" name="package" onclick="set_fee_amount()" value="12 Months"> 12 Months
                    </div>
                </div>
                <div class="row space-20">
                    <div class="col-lg-12">Total Balance Remaining : <?php echo "Rs ".$balance_remaining."<br><br>"; ?>
                    <div class="form-group">
                        <label for="amount" class="col-sm-5 control-label"> PAYMENT AMOUNT </label>

                        <div class="col-sm-4">
                    <input type="number" class="form-control" 
                    value= <?php if($discount_granted){echo "\""."$discount_factor*1500"."\"";}
                    else{echo "\""."1500"."\"";} ?> name="balance_paid" id="amount">
                            </div> 
                    <div class="col-sm-2">
                   <button type="submit" class="btn btn-sm btn-default">Submit</button>
                            </div>
                        <div class="col-sm-1"></div>
                        </div>
                    </div>
                </div>
            </form>

            <?php }else{ ?>


            <table style="font-size:12px" class="table table-striped custab">
                <thead>
                    <tr>
                        <th>Package</th>
                        <th>Balance Paid</th>
                        <th>Total Balance Remaining</th>
                        <th>Requested Date-Time</th>
                        <th>Confirmed Date-Time</th>
                        <th>Expire Date- Time</th>
                        
                    </tr>
                </thead>
                    <tr>
                        <td><?php echo $package; ?></td>
                        <td><?php echo "Rs ".$balance_paid; ?></td>
                        <td><?php echo "Rs ".$balance_remaining;  ?></td>
                        <td><?php echo $requested_datetime;  ?></td>
                        <td><?php echo $confirmed_datetime;?></td>
                        <td><?php echo $expire_datetime;?></td>
                    </tr>
            </table>

            <?php  } ?>


            </div>

            <script type="text/javascript">
                
                function set_fee_amount(){

                    var amount = document.getElementById("amount");
                                    
                    // list of avilable packages
                    
                    var packages = document.getElementsByName("package");

                    if(packages[0].checked){
                        // 1 month
                        amount.value = <?php if($discount_granted){echo $discount_factor*1500;}else{echo 1500;} ?>
                    }else if(packages[1].checked){
                        // 4 months
                        amount.value = <?php if($discount_granted){echo $discount_factor*4500;}else{echo 4500;} ?>
                    }else if(packages[2].checked){
                        // 6 months
                        amount.value = <?php if($discount_granted){echo $discount_factor*6000;}else{echo 6000;} ?>
                    }else if(packages[3].checked){
                        // 12 months
                        amount.value = <?php if($discount_granted){echo $discount_factor*9000;}else{echo 9000;} ?>
                    }



                }
            
            </script>
            

        <div class="col-lg-2"></div>

        </div>

    </div>

</div>

<?php } ?>

<!-- Health data-->
<br><br><br>



<div class="container">

    <ul id="navigate_tables" class="nav nav-tabs">
        <li ><a data-toggle="tab" href="#home">Body Measurements</a></li>
        <li><a data-toggle="tab" href="#menu1">Body Scanning</a></li>
        <li><a data-toggle="tab" href="#menu2">Scientific Tests</a></li>
        <li><a data-toggle="tab" href="#menu3">Health Background</a></li>
        <li class="active"><a data-toggle="tab" href="#menu4">Workout Schedule</a></li>
    </ul>

    <div class="tab-content" >
        <div id="home" class="tab-pane fade">
            <br><br><br>
            <div class="col-md-12">
                <div class="panel panel-default panel-table" style="overflow-x:auto;">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col col-xs-6">
                                <h3 class="panel-title">Body Measurements</h3>
                            </div>
                            <div class="col col-xs-6 text-right">
                            <?php if($Isadmin==false && $fee_form_enable == false){ ?>
                            <button onclick="refresh_table()" class=" btn btn-sm btn-success glyphicon glyphicon-refresh"></button>

                            <button type="button" 
                            onclick="insert_row('body_measurements')" 

                            class="btn btn-sm 
                            btn-primary btn-create">Create New</button>
                            <?php } ?>
                            </div>

                        </div>
                    </div>

                    <div class="panel-body">
                        <table id="body_measurements" style="font-size:12px" class="table table-striped table-bordered table-list">
                            <thead>
                                <tr>
                                    <th>Date </th>
                                    <?php if($Isadmin){ echo "<th>Member Email</th>"; } ?>
                                    <th>Height </th>
                                    <th>Weight</th>
                                    <th>Upper Abs</th>
                                    <th>Middle Abs</th>
                                    <th>Lower Abs</th>
                                    <th>Hips</th>
                                    <th>Thighs</th>
                                    <th>Left Arm</th>
                                    <th>Right Arm</th>
                                    <?php if($Isadmin==false){ echo "<th>Action</th>"; } ?>
                                </tr>
                            </thead>
                            
                            <tbody id="body_measurements_rows">                          
                            </tbody>

                        </table>

                    </div>
                    <div class="panel-footer">
                        <div class="row">
                            <div class="col col-xs-4" id="body_measurements_page_no">
                                <p>Page 1 of 5</p>
                            </div>

                            <div class="col col-xs-8">
                                <ul id="body_measurements_pagination" class="pagination hidden-xs pull-right">
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>

        <div id="menu1" class="tab-pane fade">
            <br><br><br>
            <div class="col-md-12">

                <div class="panel panel-default panel-table" style="overflow-x:auto;">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col col-xs-6">
                                <h3 class="panel-title">Body Scanning</h3>
                            </div>
                            <div class="col col-xs-6 text-right">
                                <?php if($Isadmin==false && $fee_form_enable == false){ ?>
                                <button onclick="refresh_table()" class=" btn btn-sm btn-success glyphicon glyphicon-refresh  
                                    "></button>
                                <button 
                                onclick="insert_row('body_scanning')" 
                                type="button" class="btn btn-sm btn-primary btn-create">Create New</button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table
                            id="body_scanning"
                         style="font-size:12px" class="table table-striped table-bordered table-list">
                            <thead>
                            <tr>
                                <th>Date</th>
                                <?php if($Isadmin){ echo "<th>Member Email</th>"; } ?>
                                <th>Body Fat % </th>
                                <th>metabolic age</th>
                                <th>B M I</th>
                                <th>B M R</th>
                                <th>Visceral fat %</th>
                                <th>Subcutaneous fat %</th>
                                <th>Skeletal muscle</th>
                                <?php if($Isadmin==false){ echo "<th>Action</th>"; } ?>
                            </tr>
                            </thead>

                            <tbody id="body_scanning_rows">                          
                            </tbody>
                            
                            
                        </table>

                    </div>
                    <div class="panel-footer">
                        <div class="row">
                            <div class="col col-xs-4" id="body_scanning_page_no">
                                <p>Page 1 of 5</p>
                            </div>

                            <div class="col col-xs-8">
                                <ul id="body_scanning_pagination" class="pagination hidden-xs pull-right">
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="menu2" class="tab-pane fade">
            <br><br><br>
            <div class="col-md-12">

                <div  class="panel panel-default panel-table" style="overflow-x:auto;">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col col-xs-6">
                                <h3 class="panel-title">Scientific Test </h3>
                            </div>

                            <div class="col col-xs-6 text-right">
                                <?php if($Isadmin == false && $fee_form_enable == false){ ?>
                                <button onclick="refresh_table()" class=" btn btn-sm btn-success glyphicon glyphicon-refresh"></button>
                                <button type="button" onclick="insert_row('scientific_test')" 
                                 class="btn btn-sm btn-primary btn-create">Create New</button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table id = "scientific_test"
                         style="font-size:12px" class="table table-striped table-bordered table-list">
                            <thead>
                            <tr>
                                <th>Date</th>
                                <?php if($Isadmin){ echo "<th>Member Email</th>"; } ?>
                                <th>Cardio Test </th>
                                <th>Strength Test </th>
                                <th>Endurance Test</th>
                                <th>R P R Test</th>
                                <th>Flexibility Test</th>
                                <th>Lungs Capacity</th>
                                <th>Stress Test</th>
                                <th>Skin Fold</th>
                                <th>Psychological Test</th>
                                <?php if($Isadmin==false){ echo "<th>Action</th>"; } ?>
                            </tr>
                            </thead>

                            <tbody id="scientific_test_rows">                          
                            </tbody>
                        
                        </table>

                    </div>
                    <div class="panel-footer">
                        <div class="row">
                            <div class="col col-xs-4" id="scientific_test_page_no">
                                <p>Page 1 of 5</p>
                            </div>

                            <div class="col col-xs-8">
                                <ul id="scientific_test_pagination" class="pagination hidden-xs pull-right">
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        
        <div id="menu3" class="tab-pane fade">
            <br><br><br>
            <div class="col-md-12">

                <div  class="panel panel-default panel-table" style="overflow-x:auto;">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col col-xs-6">
                                <h3 class="panel-title"> Health Background </h3>
                            </div>

                            <div class="col col-xs-6 text-right">
                                <?php if($Isadmin == false && $fee_form_enable == false){ ?>
                                <button onclick="refresh_table()" class=" btn btn-sm btn-success glyphicon glyphicon-refresh"></button>
                                <button type="button" onclick="insert_row('health_background')" 
                                 class="btn btn-sm btn-primary btn-create">Create New</button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table id = "health_background"
                         style="font-size:12px" class="table table-striped table-bordered table-list">
                            <thead>
                            <tr>
                                <th>Date</th>
                                <?php if($Isadmin){ echo "<th>Member Email</th>"; } ?>
                                <th>Doctor's Name </th>
                                <th>Phone Number </th>
                                <th>BP</th>
                                <th>Pulse</th>
                                <th>Health Issues</th>
                                <th>Reasons</th>
                                <th>Medicines</th>
                                <th>Health Advice</th>                                
                                <th>Goals</th>
                                <?php if($Isadmin==false){ echo "<th>Action</th>"; } ?>
                            </tr>
                            </thead>

                            <tbody id="health_background_rows">                          
                            </tbody>
                        
                        </table>

                    </div>
                    <div class="panel-footer">
                        <div class="row">
                            <div class="col col-xs-4" id="health_background_page_no">
                                <p>Page 1 of 5</p>
                            </div>

                            <div class="col col-xs-8">
                                <ul id="health_background_pagination" class="pagination hidden-xs pull-right">
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            
        </div>

        <div id="menu4" class="tab-pane fade in active">
            <br><br><br>
            <div class="col-md-12">

                <div  class="panel panel-default panel-table" style="overflow-x:auto;">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col col-xs-12">
                                <h3 class="panel-title">Workout Schedule</h3>
                                

                            </div>
                        </div>    

                        <?php if($fee_form_enable == false){ 

                            $email_value = "";
                            $email_status = "<p id=\"chk_available\">check email</p>";

                            if($Isadmin == false){
                            $email_value = $_SESSION['email'];
                            $email_status = "<p id=\"chk_available\">Email already exists</p>";
                            }

                         ?>

                        <div class="row">
                            <div class="col col-xs-3">
                                <legend>Exercise Category :</legend>
                                <select id="exercise_category_ws" class="form-control">
                                    <option value="Neck Pain">Neck Pain</option>
                                    <option value="Back Pain">Back Pain</option>
                                    <option value="Knee Pain">Knee Pain</option>
                                </select>
                            </div>

                            
                            <div class="col col-xs-2">
                                <legend>Select Date :</legend>

                                <input type="date" id="date_ws" class='input-sm' 
                                value='<?php echo date("Y-m-d");?>'

                                style='height:25px; width:140px;' > <br><br>

                                <br><br>
                            
                            </div>

                            <div class="col col-xs-3">
                                <legend>Select Email :</legend>

                                <input type="email" id="email_id" 
                                <?php echo "value='$email_value'"; ?>
                                
                                class='input-sm' style='height:30px; width:140px;'> 

                                <button onclick="is_email_available()" 
                                class="btn btn-sm btn-danger glyphicon glyphicon-envelope">
                                </button>

                                <br><br>
                                <?php echo $email_status; ?>

                            </div>

                            <div class="col col-xs-1">
                                <button type="button" 
                                 onclick="insert_multiple_rows('workout_schedule',10)" 
                                 class="btn btn-sm btn-primary btn-create">Full Workout
                                </button>
                            </div>
                            <div class="col col-xs-1">

                                <button type="button" 
                                onclick="insert_multiple_rows('workout_schedule',1)" 
                                class="btn btn-sm btn-primary btn-create">Create New
                                </button>

                            </div>

                        

                            <div class="col col-xs-1">
                                <button onclick="refresh_table()" 
                                class="btn btn-sm btn-success glyphicon glyphicon-refresh">
                                </button>
                            </div>
                        
                        </div>
                        <?php } ?>
                        

                        <script type="text/javascript" src="ajax_js/is_email_available.js" > </script>



                    </div>
                    <div class="panel-body">
                        <table  id = "workout_schedule"
                         style="font-size:12px" class="table table-striped table-bordered table-list">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Member Email</th>
                                    <th>Exercise Name </th>
                                    <th>Sets</th>
                                    <th>Reps Current</th>
                                    <th>Reps Target</th>                                    
                                    <th>Exercise Category</th>
                                    <th>Body Area</th>
                                    <th>Remarks</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="workout_schedule_rows">
                            </tbody>

                        </table>

                    </div>
                    <div class="panel-footer">
                        <div class="row">
                            <div class="col col-xs-4" id="workout_schedule_page_no">
                                <p>Page 1 of 5</p>
                            </div>

                            <div class="col col-xs-8">
                                <ul id="workout_schedule_pagination" class="pagination hidden-xs pull-right">
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>                  
    </div>
</div>

<script type="text/javascript" src="ajax_js/display_rows.js">
</script>

<script type="text/javascript" src="ajax_js/fill_table_details.js">
</script>

<!-- end of Health data-->


<?php

include('includes/footer.php');

?>

	
</body>
</html>