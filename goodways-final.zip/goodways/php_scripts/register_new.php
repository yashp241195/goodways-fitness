<?php 

include('../includes/common.php');

// Create new entry

//Store form values into variables

$member_name = mysqli_real_escape_string($conn,$_POST['name']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$password = mysqli_real_escape_string($conn,$_POST['password']);
$phone = mysqli_real_escape_string($conn,$_POST['phone']);
$gender = mysqli_real_escape_string($conn,$_POST['gender']);
$address = mysqli_real_escape_string($conn,$_POST['address']);
$blood_group = mysqli_real_escape_string($conn,$_POST['blood_group']);
$date_of_birth = mysqli_real_escape_string($conn,$_POST['date_of_birth']);
$position = mysqli_real_escape_string($conn,$_POST['position']);
$user_type = mysqli_real_escape_string($conn,$_POST['user_type']);
$verification = mysqli_real_escape_string($conn,$_POST['verification']);


// $test_password_before = " password : $password ";

// encrypting password
// $password = md5($password);

// $test_password_after = " password : $password ";

// testing the signup 

/*

$test = "member_name : $member_name , email : $email , password : $password
	phone : $phone , gender : $gender , address : $address
	blood_group : $blood_group , date_of_birth : $date_of_birth";

*/

if($gender == "female"){
        $file_profile_image = file_get_contents('../images/profile-default-female.jpg');
    }else{
        $file_profile_image = file_get_contents('../images/profile-default-male.jpg');
 }

$profile_pic = base64_encode($file_profile_image);
/*
	$test_images = "<img src=\"data:image;base64,$profile_pic\" width=\"250\" height=\"250\"
 	alt=\"profile pic\" class=\"img thumbnail\" >";
*/

// echo " $test $test_password_before $test_password_after $test_images"; 

// admin should be verified by passkey
$passkey = "2495";

if($user_type == "Admin" && $verification === $passkey){


	$user_registration_query = "insert into admin_users(admin_name,admin_email,password,phone_number,address,gender,date_of_birth,blood_group,profile_pic,position) values ('$member_name',
	'$email','$password','$phone','$address','$gender','$date_of_birth','$blood_group','$profile_pic','$position')";

	$user_registration_submit = mysqli_query($conn, $user_registration_query) or 
	die(mysqli_error($conn));


	$_SESSION['email'] = $email;

	// returns the auto-generated incremented vale in table
	// we always auto increment the primary key value

	$_SESSION['id'] = mysqli_insert_id($conn);
	$_SESSION['Isadmin'] = true;


}else{

	$user_registration_query = 
	"insert into member_users(member_name,email,password,phone_number,
	address,gender,date_of_birth,blood_group,profile_pic) values ('$member_name'
	,'$email','$password','$phone','$address','$gender','$date_of_birth',
	'$blood_group','$profile_pic')";

	$user_registration_submit = mysqli_query($conn, $user_registration_query) or 
	die(mysqli_error($conn));


	$_SESSION['email'] = $email;

	// returns the auto-generated incremented value in table
	// we always auto increment the primary key value

	$_SESSION['id'] = mysqli_insert_id($conn);
	$_SESSION['Isadmin'] = false;


}


header('location: ../home.php');
exit();


?>