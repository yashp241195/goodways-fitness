<?php 
require('../includes/common.php');
include('../includes/is_auth.php');


//Store form values into variables

$fee_id = $_POST['fee_id'];

$remove_cart_query = "DELETE FROM my_fee WHERE fee_id ='$fee_id'";
$remove_cart_result = mysqli_query($conn, $remove_cart_query) or die(mysqli_error($conn));

echo "Payment Declined";


?>