<?php

include('../includes/common.php');
include('../includes/is_auth.php');
header("Content-Type: application/json; charset=UTF-8");

$Isadmin = $_SESSION['Isadmin'];


if($_POST['page_no'] != Null && $_POST['row_limit'] != Null){
	
	$page_no = $_POST['page_no'];
	$row_limit = $_POST['row_limit'];

	$offset = ($page_no-1) * $row_limit;
	$total_row_count = 0;

	$heading = "Your Notifications";

	$all_row = "";	

	if($Isadmin == true){

		// Display Notifications - latest

		$heading = "All Member's Notifications";
		
		$select_query = "SELECT COUNT(notifications_id) from notifications order by status asc,date desc";

		$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
		$row = mysqli_fetch_array($select_query_result);

		$total_row_count = $row['COUNT(notifications_id)'];

	    $select_query = "SELECT * from notifications order by status asc,date desc";

		$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
		$notifications = $select_query_result;

				

	}else{


		// Display Notifications - latest

		$email = $_SESSION['email'];

		$select_query = "SELECT COUNT(notifications_id) from notifications
	    where email = '$email' order by status asc,date desc";

		$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
		$row = mysqli_fetch_array($select_query_result);

		$total_row_count = $row['COUNT(notifications_id)'];

	    $select_query = "SELECT * from notifications where email = '$email' 
	    order by status asc,date desc";

		$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
		$notifications = $select_query_result;

	}

	// fetch query result row wise 
    
    while ($row = mysqli_fetch_array($notifications)){
        
        $notifications_id = $row['notifications_id'];
        $date = date_format(date_create($row['date']), 'd-m-Y');
        $email_id = $row['email'];
        $notifications_message = $row['notifications_message'];
        $status = $row['status'];


        if($Isadmin == true){

        	$unsend = "<a id=\"notifications_row_$notifications_id\" onclick='delete_row_db($notifications_id,\"notifications\")' class=\"glyphicon glyphicon-trash btn btn-xs btn-danger\">Unsend</a>";

        	if($status == -1){
        		$status = "$unsend";
        	}else if($status == 1){
        		$status = "read";
        	}

			$display_row = "<tr>
					            <td>$date</td>
					            <td>$email_id</td>
					            <td>$notifications_message</td>
					            <td>$status</td>
					        </tr>";  
			
        }
        else{

        	$mark_read = "<a id=\"notifications_mark_read_$notifications_id\" 
        	onclick=\"mark_read($notifications_id)\" class=\"glyphicon glyphicon-pencil 
        	btn btn-xs btn-primary\">read</a>";

			if($status == -1){
        		$status = $mark_read;
        	}else{
        		$status = "read";
        	}

 
        	$display_row = "<tr>
					            <td>$date</td>
					            <td>$notifications_message</td>
					            <td>$status</td>
					        </tr>";  

        }

        
        $all_row .= $display_row; 

    } 

    $my_array = array($all_row,$total_row_count,$heading);
	echo json_encode($my_array);
	

}




?>