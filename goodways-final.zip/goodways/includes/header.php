<?php

$header0 = '

<html>
<head>
  <title>Goodways Fitness</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/index.css" rel="stylesheet" type="text/css" /> 
  <link href="css/login_css.css" rel="stylesheet" type="text/css" /> 
  <link rel="stylesheet" type="text/css" href="css/table.css">


</head>
<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand " href="index.php">  Goodways Fitness  </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
  
      	';
	  
	$header1 = '';	
	$header2 = '';


	
	if(isset($_SESSION['email'])){

        if($_SESSION['Isadmin']){
            $header1 ='
			<ul class="nav navbar-nav navbar-right">
        <li><a href="notifications.php"><span class="glyphicon glyphicon-bell"></span> Notify</a></li>
        <li><a href="my_fee.php"><span class="glyphicon glyphicon-usd"></span> All Fee</a></li>
              <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <span class="glyphicon glyphicon-eye-open"></span> Attendance <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="my_attendance.php">Member Attendance</a></li>
                  <li><a href="all_attendance_staff.php">Staff Attendance</a></li>
                </ul>
              </li>

        
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
        <span class="glyphicon glyphicon-ok"></span> Approve <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="approve_payments.php">Approve Payments</a></li>
            <li><a href="approve_deletion.php">Approve Account Deletion</a></li>
          </ul>
        </li>
        <li><a href = "logout.php"><span class = "glyphicon glyphicon-log-out"></span> Logout</a></li> 
			';
        }else{

            $header1 ='
			<ul class="nav navbar-nav navbar-right">
      <li><a href="notifications.php"><span class="glyphicon glyphicon-bell"></span> Notify</a></li>
       <li><a href="workout_card.php"><span class="glyphicon glyphicon-credit-card "></span> Workout </a></li>
				<li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <span class="glyphicon glyphicon-eye-open"></span> Attendance <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="my_attendance.php">Member Attendance</a></li>
                  <li><a href="all_attendance_staff.php">Staff Attendance</a></li>
                </ul>
              </li>
  

        
				<li><a href="my_fee.php"><span class="glyphicon glyphicon-usd"></span> Fee</a></li>
				<li><a href = "settings.php"><span class = "glyphicon glyphicon-user"></span> 
        Settings</a></li> 
				<li><a href = "logout.php"><span class = "glyphicon glyphicon-log-out"></span> 
        Logout</a></li> 
			';
		}

	}else{
		$header1='
		  <ul class="nav navbar-nav navbar-right">
		 	 <li class="dropdown">
		 			
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    Already a member ? <span class="glyphicon glyphicon-log-in"></span>
                    Login <span class="caret"></span></a>
                    <ul id="login-dp" class="dropdown-menu">
                        <li>
                            <div class="row">
                                <div class="col-md-12">
                                    Login here
                                    <br>
                                    <br>
                                    
                                    <form class="form" role="form" method="post" action="php_scripts/auth.php" accept-charset="UTF-8" id="login-nav">
                                        <div class="form-group">
                                            <label class="sr-only" for="exampleInputEmail2">Email address</label>
                                            <input type="email" class="form-control" name="email" " placeholder="Email address" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="sr-only" for="exampleInputPassword2">Password</label>
                                            <input type="password" class="form-control" name="password" id="exampleInputPassword2" placeholder="Password" required>
                                            <div class="help-block text-right"><a href="">Forget the password ?</a></div>
                                        </div>
                                        <div class="form-group">
											<label class="radio-inline">
											  <input type="radio" name="opt_account" value ="user" checked> User
											</label>
											<label class="radio-inline">
											  <input type="radio" name="opt_account" value ="admin" > Admin
											</label>
										</div>
										
                    <div class="form-group">
                       <button type="submit" class="btn btn-primary btn-block">Sign in</button>
                    </div>
                  </form>
                </div>
                <div class="bottom text-center">
                    <a href="#"><b></b></a>
                </div>
            </div>
        </li>
    </ul>
  </li>
          
	';

	}



	$header2 = '
		 
      </ul>
    </div>
  </div>
</nav>

';

$final = $header0.$header1.$header2;

echo $final;

?>
