<?php

$footer = '
</body>
<br />
<br />
<br />
<div class="container ">
	<div class="navbar-fixed-bottom text-center">
	<footer>
			<p>Copyright © Goodways Fitness. All Rights Reserved | Contact Us: +91 90000 00000</p>
	</footer>	
</div>
';

echo $footer;
?>
