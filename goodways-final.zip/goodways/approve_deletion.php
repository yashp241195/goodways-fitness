<?php

require('includes/common.php');

if(!(isset($_SESSION['email']) && $_SESSION['Isadmin'])){
	header('location: home.php');
	exit();
}

include('includes/header.php');



$select_query = "SELECT * from account_deletion inner join 
member_users on member_users.member_id = account_deletion.member_id
where account_deletion.status = -1 ORDER BY confirmed_datetime DESC";

$select_query_result = mysqli_query($conn,$select_query);

?>

<div class="container">
    <div  class="panel panel-default panel-table" style="overflow-x:auto;">
        <div class="panel-heading">
            <div class="row">
                <div class="col col-xs-6">
                    <h3 class="panel-title"><b id="approve_payments_heading"> Approve Account Deletion Requests </b></h3>
                </div>
                <div class="col col-xs-6 text-right">
                    <button onclick="location.reload()" 
                    class=" btn btn-sm btn-success glyphicon glyphicon-refresh"></button>
                </div>
            </div>
            <div class="row">
                <div class="col col-xs-12">
                    <br><br><br>
                </div>
                
            </div>
        </div>


        <div class="panel-body">
            <table style="font-size:12px" class="table table-striped table-bordered table-list">
                <thead>
                    <tr>
                       	<th>S No</th>
                      	<th>Member Name</th>
                        <th>Member Email </th>
                        <th>Phone Number </th>
                		<th>Requested Date</th>
                		<th>Requested Time</th>
                		<th class="text-center">Action</th>
                    </tr>
                </thead>
    	
                <tbody>

                    <?php

                    $s_num = 1;
                    // fetch query result row wise 

                    while ($row = mysqli_fetch_array($select_query_result)){

                        $account_deletion_id = $row['account_deletion_id'];
                        $phone_number = $row['phone_number'];

                        $member_name = $row['member_name'];

                        $requested_date = date_format(date_create($row['requested_datetime']), 'd-m-Y');
                        $requested_time = date_format(date_create($row['requested_datetime']), 'H:i:s');
                        
                        $email_id = $row['email'];
                        $status = $row['status'];

                        if($status == 1){

                            $action =  "deleted confirmed";
                        }
                        if($status == -1){
                            
                            $date1 = new DateTime(date("Y-m-d"));
                            $date2 = new DateTime($requested_date);
                            $diff = $date1->diff($date2);


                            $remaining = ($diff->d);
                            // echo $remaining;

                            if($remaining < 3){
                                $action  = "wait for ".(3-$remaining)." days";
                            }else{
                                $action  = "<a class=\"glyphicon glyphicon-ok col-xs-4 
                                btn btn-xs btn-success\" onclick=\"confirm_delete($account_deletion_id,'row_$s_num')\">Confirm</a>
                                <span class = \"col-xs-1\"></span>
                                <a class=\"glyphicon glyphicon-ok col-xs-4 
                                btn btn-xs btn-danger\" onclick=\"reject_delete($account_deletion_id,'row_$s_num')\">Reject</a>
                                <span class = \"col-xs-3\"></span>
                                ";
                            }

                        }
                        if($status == 2){
                            $action = "deletion rejected";

                        }
                        


                        $display_content = "
                        <tr>
                        <td>$s_num</td><td>$member_name</td><td>$email_id</td>
                        <td>$phone_number</td><td>$requested_date</td>
                        <td>$requested_time</td>
                        <td id=\"row_$s_num\">
                        $action
                        </td>
                        </tr>";   

                        echo $display_content;

                         $s_num++; } 


                    ?>

                 </tbody>
            </table>
        </div>
        <div class="panel-footer">
                    <div class="row">
                        <div class="col col-xs-4" id="approve_payments_page_no">
                            <p>Approve Deletion</p>
                        </div>

                        <div class="col col-xs-8">
                            <ul id="approve_payments_pagination" class="pagination hidden-xs pull-right">
                            </ul>
                        </div>
                    </div>
        </div>
    
    </div>
</div>

<script type="text/javascript">
   function confirm_delete(account_deletion_id,row_id){
    
    var xmlhttp = new XMLHttpRequest();

    xmlhttp.open("POST", "php_scripts/confirm_reject_account_deletion.php", true);
    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var status = document.getElementById(row_id); 
            status.innerHTML =  xmlhttp.responseText;
            console.log(xmlhttp.responseText);
        }
    };

    xmlhttp.send('account_deletion_id='+account_deletion_id+"&accept_delete=1&reject_delete=0");


   }function reject_delete(account_deletion_id,row_id){

    var xmlhttp = new XMLHttpRequest();

    xmlhttp.open("POST", "php_scripts/confirm_reject_account_deletion.php", true);
    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var status = document.getElementById(row_id); 
            status.innerHTML =  xmlhttp.responseText;
            console.log(xmlhttp.responseText);
        }
    };

    xmlhttp.send('account_deletion_id='+account_deletion_id+"&reject_delete=1&accept_delete=0");


    
   }

</script>


<br />
<br />
<br />
<br />
<br />
<br />


<?php
include('includes/footer.php');
?>

