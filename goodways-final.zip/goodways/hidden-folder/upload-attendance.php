<?php

require('../includes/common.php');

if(!(isset($_SESSION['email']))){
	header('location: ../index.php');
	exit();
}

$member_id = $_SESSION['id'];
$current_datetime = date('Y-m-d H:i:s');

if($_SESSION['Isadmin']){

	$entry_datetime = $current_datetime;
	$exit_datetime = date('Y-m-d H:i:s', strtotime("+8 hours", strtotime($entry_datetime)));

	$query = "INSERT into staff_attendance(user_id,entry_datetime,exit_datetime)
	values('$member_id','$entry_datetime','$exit_datetime')";

	$attendance = mysqli_query($conn, $query) or die(mysqli_error($conn));


}
else{

	$entry_datetime = $current_datetime;
	$exit_datetime = date('Y-m-d H:i:s', strtotime("+2 hours", strtotime($entry_datetime)));

	$query = "INSERT into attendance(user_id,entry_datetime,exit_datetime)
	values('$member_id','$entry_datetime','$exit_datetime')";

	$attendance = mysqli_query($conn, $query) or die(mysqli_error($conn));

}

// echo "$member_id, $current_datetime, $entry_datetime, $exit_datetime";



?>