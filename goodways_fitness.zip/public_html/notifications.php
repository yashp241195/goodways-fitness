<?php 

require('includes/common.php');
include('includes/is_auth.php');
include('includes/header.php');

$Isadmin = $_SESSION['Isadmin'];





?>

<div class="container">
    <div  class="panel panel-default panel-table" style="overflow-x:auto;">
        <div class="panel-heading">
            <div class="row">
                <div class="col col-xs-12">
                    <h3 class="panel-title"><b id="notifications_heading"> Notifications </b></h3>
                </div>
            </div>
			
			<?php if($Isadmin){ ?>
	            <div class="row">
	                <div class="col col-xs-3">
                        <a class="btn btn-md btn-primary" href="php_scripts/generate_notifications.php">Generate Notifications</a>
	                </div>
	                
	                <div class="col col-xs-2">
	                    <legend>Select Date :</legend>

	                    <input type="date" id="date_notify" class='input-sm' 
	                    style='height:25px; width:140px;' > <br><br>

	                    <br><br>
	                
	                </div>

	                <div class="col col-xs-3">
	                    <legend>Select Email :</legend>

	                    <input type="email" id="email_id" 
	                    class='input-sm' style='height:30px; width:140px;' > 

	                    <button onclick="is_email_available()" 
	                    class="btn btn-sm btn-danger glyphicon glyphicon-envelope">
	                    </button>

	                    <br><br>
	                    <p id="chk_available">check email</p>

	                </div>

	                <div class="col col-xs-1">
	                    <button type="button" 
	                     onclick="insert_multiple_rows('notifications',10)" 
	                     class="btn btn-sm btn-primary btn-create">Create Full
	                    </button>
	                </div>
	                <div class="col col-xs-1">

	                    <button type="button" 
	                    onclick="insert_multiple_rows('notifications',1)" 
	                    class="btn btn-sm btn-primary btn-create">Create New
	                    </button>

	                </div>

	            

	                <div class="col col-xs-1">
	                    <button onclick="refresh_table()" 
	                    class="btn btn-sm btn-success glyphicon glyphicon-refresh">
	                    </button>
	                </div>
	            
	            
	        	</div>
        	<?php }?>
            <div class="row">
                <div class="col col-xs-12">
                </div>
                
            </div>
        </div>

                <div class="panel-body">
                    <table style="font-size:12px;" id="notifications"
                    class="table table-striped table-bordered table-list">
                        <thead>
                            <tr>
                                <th>Date </th>
                                <?php if($Isadmin == true){echo "<th>Members Email</th>";} ?>
                                <th>Notification Message </th>
                                <th>Status </th>
                            </tr>
                        </thead>

                        <tbody id="notifications_rows">
                        </tbody>
                
                    </table>
                </div>
        <div class="panel-footer">
            <div class="row">
                <div class="col col-xs-4" id="notifications_page_no">
                    <p>Page 1 of 10</p>
                </div>

                <div class="col col-xs-8">
                    <ul id="notifications_pagination" class="pagination hidden-xs pull-right">
                    </ul>
                </div>
            </div>
        </div>
    
    </div>
</div>

<script type="text/javascript" src="ajax_js/is_email_available.js" > </script>


<script type="text/javascript">
    

    var page_count = 1;


    function set_table_page_limit(table_name,value){

        switch(table_name){

            case "notifications":                
                page_count = value;
                break;

            
            }

    }

    function get_table_page_limit(table_name){

        switch(table_name){

            case "notifications":                
                return page_count;

            }
            
    }

    function get_table_data(t_name, page_no){

        var row_limit_per_page = 20;

        var xmlhttp = new XMLHttpRequest();

        // always put address of the page where function is called
        // here ../ajax_php/is_email_available.php does not work

        xmlhttp.open("POST", "ajax_php/display_rows_notifications.php", true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xmlhttp.onreadystatechange = function() {

                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                    var row_item = document.getElementById(t_name+"_rows"); 
                    var pagination = document.getElementById(t_name+"_page_no");
                    var heading = document.getElementById(t_name+"_heading");

                    // console.log(xmlhttp.responseText);
                                       
                    
                    var recieve = JSON.parse(xmlhttp.responseText);

                    row_item.innerHTML = recieve[0];
                    page_max_limit = parseInt(recieve[1]/row_limit_per_page)+1;

                    set_table_page_limit(t_name,page_max_limit);

                    pagination.innerText = "Page "+page_no+" of "+page_max_limit;

                    heading.innerText = recieve[2];
                    
                    
                }
            };

            xmlhttp.send('page_no='+page_no+'&row_limit='+row_limit_per_page);

    }

    function pageination(t_name, pg=1){

        if(pg < 1){
            pg = 1;
        }

        var page_limit = get_table_page_limit(t_name);

        // console.log(page_limit);

        if(pg > page_limit){
            return 0;
        }

        var total_pg = 4;

        pg_before = (pg - total_pg);
        pg_after = (pg + total_pg);

        if((page_limit/total_pg) < 1){
            pg_after = page_limit;
        }
        
        var text = "<li><a href=\"#\" onclick=\"pageination('"+t_name+"',"+pg_before+")\">«</a></li>";
        
        for (var i = pg; i <= pg_after; i++) {
            text += "<li><a href=\"#\" onclick=\"get_table_data('"+t_name+"',"+i+")\">"+i+"</a></li>";
        }

        text += "<li><a href=\"#\" onclick=\"pageination('"+t_name+"',"+pg_after+")\">»</a></li>";

        var pagination_view = document.getElementById(t_name+"_pagination");
        pagination_view.innerHTML = text;


    }


    get_table_data("notifications",1);
    pageination('notifications');



    function mark_read(notifications_id){

        var xmlhttp = new XMLHttpRequest();

        xmlhttp.open("POST", "php_scripts/notifications_mark_read.php", true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                
                var status = document.getElementById("notifications_mark_read_"+notifications_id);
                status.parentElement.innerText =  xmlhttp.responseText;

                console.log(xmlhttp.responseText);
            }
        };

        xmlhttp.send('notifications_id='+notifications_id);
    }

	// notifications

	var notifications = [
            ["date","date","140","",""],
            ["email","email","120","",""],
            ["notifications_message","text","440","",""],                         
        ];

    var col_count_notify = 1;
    var col_max_count_notify = notifications.length;




    function col_count_change(table_name,sign_value=0){

        switch(table_name){

            case "notifications":                
                col_count_notify += sign_value;
                break;

        }

    }

    function get_col_count_array(table_name){

        switch(table_name){

            case "notifications":
                col_count = col_count_notify;
                col_max_count = col_max_count_notify;
                break;

        }

        return [col_count,col_max_count];

    }

    
    function get_col_property_array(table_name,column_no){

        var i = column_no;

        switch(table_name){

                case "notifications":
                    col_name = notifications[i][0];
                    col_type = notifications[i][1];
                    col_width = notifications[i][2];
                    col_text_suffix = notifications[i][3];
                    col_value = notifications[i][4];
                    break;

                
        }

        return [col_name, col_type, col_width, col_text_suffix, col_value];

    }



	function insert_row(table_name){
                
        table = document.getElementById(table_name);

        var array = [];
        array = get_col_count_array(table_name);
        
        var col_count = array[0];
        var col_max_count = array[1];
        
        var row = table.insertRow(col_count);
                
        for (var i = 0; i < col_max_count; i++) {

            var column_property_array = [];
            column_property_array = get_col_property_array(table_name,i);

            col_name = column_property_array[0];
            col_type = column_property_array[1];
            col_width = column_property_array[2];
            col_text_suffix = column_property_array[3];
            col_value = column_property_array[4];

            row.insertCell(i).innerHTML = "<input"+ " name='"+col_name+
            "' type='"+ col_type+"' "+"value='"+col_value+"' "+
            "class='input-sm' style='height:25px; width:"+col_width+"px;' >"
            +col_text_suffix;

        }

        var del_str = "<a class='glyphicon glyphicon-trash btn btn-xs btn-danger' ";
        del_str += "onclick= \"delete_row("+col_count+",'"+table_name+"')\">Discard</a>";

        var save_str = "<a class='glyphicon glyphicon-send btn btn-xs btn-primary' ";
        save_str += "onclick= \"save_row("+col_count+",'"+table_name+"')\">Send</a>";

        row.insertCell(col_max_count).innerHTML ="<div><div class='row'>"+
        "<div class='col-xs-12 col-sm-5'>"+save_str+"</div><div class='col-xs-12  col-sm-3'>"+
        del_str+"</div></div></div>";

        // increment count
        col_count_change(table_name,1);


    }


	function save_row(j,table_name){

        var table = document.getElementById(table_name);

        var content = table.rows[j].cells;

        // accessing each cell

        cell_values = [];
        cell_col_names = [];

        var max_count = content.length-1;

        for (var i = 0; i < max_count; i++) {
            
            var my_value = content[i].firstElementChild.value;
            var my_name = content[i].firstElementChild.name;
                
            cell_values.push(my_value);
            cell_col_names.push(my_name);

            var column_property_array = [];

            column_property_array = get_col_property_array(table_name,i);
            col_text_suffix = column_property_array[3];
           
            var units = String(col_text_suffix);

            content[i].innerHTML = ""+my_value+" "+units;
            
        }


        var arr_vals = JSON.stringify(cell_values);
        var arr_names = JSON.stringify(cell_col_names);
        var t_name = JSON.stringify(table_name);

        console.log(t_name,arr_vals,arr_names);


        var xmlhttp = new XMLHttpRequest();

        xmlhttp.open("POST", "ajax_php/insert_row.php", true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.onreadystatechange = function() {

            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var status = content[content.length-1]; 
                status.innerHTML =  xmlhttp.responseText;
                console.log(xmlhttp.responseText);
            }
        
        };

        xmlhttp.send('arr_vals='+arr_vals+'&arr_names='+arr_names+'&t_name='+t_name);


    }

	function delete_row(j,table_name) {

      document.getElementById(table_name).deleteRow(j);
      
      // decrement count
      col_count_change(table_name,-1);
      
    }


    function delete_row_db(j,table_name) {

        var xmlhttp = new XMLHttpRequest();

        xmlhttp.open("POST", "ajax_php/delete_row.php", true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var table_row_action = document.getElementById(table_name+"_row_"+j).parentElement;
                // delete button does not exist in edit_row, table updatation 
                if(table_row_action != null){
                    table_row_action.innerHTML =  xmlhttp.responseText;
                }                 
                console.log(xmlhttp.responseText);
            }
        };
        
        var t_name = JSON.stringify(table_name);
        var t_id = JSON.stringify(j);

        xmlhttp.send('t_id='+j+'&t_name='+t_name);
      
    }


   

	function insert_multiple_rows(table_name,num){

        if(table_name == "notifications"){

            var chk = document.getElementById("chk_available");
            
            if(chk.textContent != "Email already exists"){                
            	return 0;
        	}


            var email = document.getElementById("email_id").value;
            console.log("email : "+email);
            notifications[1][4] = email;
                
            var date = document.getElementById("date_notify").value;
            
            // console.log("Date : "+String(date));

            if(String(date) == ""){
				date = getTodaysDate();

            }
            
			date = String(date);

            notifications[0][4] = date;
            console.log("date : "+date);

        }

        for(i=0; i<num; i++){
            insert_row(table_name);
        }

        // reset
        // workout_schedule[0][4] = "";
        // workout_schedule[1][4] = "";
        

    }

	function refresh_table(){
        window.location.reload(true);
    }

    function getTodaysDate(){

    	var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0!
		var yyyy = today.getFullYear();

		if(dd<10) {
		    dd = '0'+dd;
		} 

		if(mm<10) {
		    mm = '0'+mm;
		} 

		today = yyyy + '-' + mm + '-' + dd;
		return today;
    }


</script>

<?php
include('includes/footer.php');
?>
