<?php 
include('../includes/common.php');
include('../includes/is_auth.php');


//Store form values into variables


$member_id = $_SESSION['id'];
$requested_datetime = date('Y-m-d H:i:s');
$balance_paid = $_POST['balance_paid'];
$package = $_POST['package'];


$payfee = "INSERT INTO my_fee(member_id,requested_datetime,balance_paid,package) values";
$payfee .= "('$member_id','$requested_datetime','$balance_paid','$package')";

mysqli_query($conn, $payfee) or die(mysqli_error($conn));

echo "<center>Payment Suceessfully registered with amount Rs ".$balance_paid."<br>";	
echo "<a href=\"..\home.php\">Click here</a> to go back </center>";

exit();

?>