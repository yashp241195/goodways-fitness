<?php 
include('../includes/common.php');
include('../includes/is_auth.php');

header("Content-Type: application/json; charset=UTF-8");

$Isadmin = $_SESSION['Isadmin'];

if($Isadmin == false){
	header('location: ../index.php');
	header('location: index.php');
	exit();
}


if ($_POST['reject_delete'] == 1 && $_POST['account_deletion_id'] != Null) {
		echo "qq";

	// reject the deletion
	$account_deletion_id = $_POST['account_deletion_id'];

	$query = "SELECT * from account_deletion where account_deletion_id='$account_deletion_id'";
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));

	$row = mysqli_fetch_array($result);
	$member_id = $row['member_id'];
	$confirmed_datetime = date('Y-m-d H:i:s');
	$admin_id = $_SESSION['id'];



	$query = "UPDATE account_deletion SET status='2',confirmed_datetime='$confirmed_datetime',
	admin_id='$admin_id' where account_deletion_id='$account_deletion_id'";

	mysqli_query($conn, $query) or die(mysqli_error($conn));

	echo "deletion is rejected";


}

if ($_POST['accept_delete'] == 1 && $_POST['account_deletion_id'] != Null){
	
	$account_deletion_id = $_POST['account_deletion_id'];

	// start deletion

	$query = "SELECT * from account_deletion where account_deletion_id='$account_deletion_id'";
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));

	$row = mysqli_fetch_array($result);
	$member_id = $row['member_id'];
	$confirmed_datetime = date('Y-m-d H:i:s');

	/* Account data should be deleted first */

	$query = "DELETE from attendance where user_id='$member_id'";
	mysqli_query($conn, $query) or die(mysqli_error($conn));

	$query = "DELETE from body_measurements where user_id='$member_id'";
	mysqli_query($conn, $query) or die(mysqli_error($conn));

	$query = "DELETE from body_scanning where user_id='$member_id'";
	mysqli_query($conn, $query) or die(mysqli_error($conn));

	$query = "DELETE from scientific_test where user_id='$member_id'";
	mysqli_query($conn, $query) or die(mysqli_error($conn));

	$query = "DELETE from my_fee where member_id='$member_id'";
	mysqli_query($conn, $query) or die(mysqli_error($conn));

	// echo "Account Data Deleted successfully";

	// /* Account data should be deleted first */

	// $query = "DELETE from member_users where member_id='$member_id'";
	// mysqli_query($conn, $query) or die(mysqli_error($conn));

	// echo "Member Account Deleted successfully";

	$admin_id = $_SESSION['id'];

	$query = "UPDATE account_deletion SET status='1',confirmed_datetime='$confirmed_datetime',
	admin_id='$admin_id' where account_deletion_id='$account_deletion_id'";

	mysqli_query($conn, $query) or die(mysqli_error($conn));

	// echo "Deletion History Updated Successfully";

	echo "Deletion is confirmed";


}






?>
