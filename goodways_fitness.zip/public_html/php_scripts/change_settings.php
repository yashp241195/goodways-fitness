<?php 
require('../includes/common.php');
include('../includes/is_auth.php');


//Store form values into variables

$email = $_SESSION['email'];
$member_id = $_SESSION['id'];

if($email == null){
	header('location: ../index.php');
	exit();
}


$update_pass = isset($_POST['update_password']);
$request_deletion = isset($_POST['request_deletion']);

echo "<center>";

if($update_pass){
	$password_old = $_POST['old_password'];
	$password_new = $_POST['new_password'];

	$password_update_query = "UPDATE member_users SET password = '$password_new' WHERE email = '$email' 
	AND password = '$password_old' ";

	$mysqli_result = mysqli_query($conn, $password_update_query) or die(mysqli_error($conn));
	echo "password updated";
	echo "<a href=\"..\home.php\">Click here</a> to go back </center>";

	exit(); 
}


if($request_deletion){

	$requested_datetime = date('Y-m-d H:i:s');
	$current_password = $_POST['current_password'];

	$validate = "SELECT * from member_users WHERE email = '$email' AND password = '$current_password' ";
	$mysqli_result = mysqli_query($conn, $validate) or die(mysqli_error($conn));

	if(mysqli_num_rows($mysqli_result) == 1){

		$request_deletion = "INSERT into account_deletion
		(member_id,member_email,requested_datetime)values
		('$member_id','$email','$requested_datetime')";

		$mysqli_result = mysqli_query($conn, $request_deletion) or die(mysqli_error($conn));

		echo "deletion requested";
	}else{
		echo "wrong password";
	}

	echo "<br><a href=\"..\home.php\">Click here</a> to go back </center>";

	exit(); 

}

echo "Not done";


?>