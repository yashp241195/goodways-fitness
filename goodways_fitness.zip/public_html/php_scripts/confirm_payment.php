<?php 
require('../includes/common.php');
include('../includes/is_auth.php');

header("Content-Type: application/json; charset=UTF-8");

//Store form values into variables

$fee_id = $_POST['fee_id'];
$approver = $_SESSION['id'];
$Isadmin = $_SESSION['Isadmin'];

if($Isadmin == false){
	header('location: ../index.php');
	header('location: index.php');
	exit();
}

$get_package_details = "SELECT package,balance_paid,member_id from my_fee where fee_id = '$fee_id'";
$get_package_details = mysqli_query($conn, $get_package_details) or die(mysqli_error($conn));

 
$row = mysqli_fetch_array($get_package_details);

$package_name = $row['package'];
$balance_paid = $row['balance_paid'];
$member_id = $row['member_id'];

$confirmed_datetime = date('Y-m-d H:i:s');


// first payment - 10% off ;
// if no fee_id with status = 1 exist then give it 10% discount

$first_fee = "SELECT * from my_fee where member_id = '$member_id' and status = '1' order by expire_datetime desc";
$first_fee = mysqli_query($conn, $first_fee) or die(mysqli_error($conn));

$discount_granted = false;

$balance_remaining = 0;
$prev_balance_remaining = 0;

if(mysqli_num_rows($first_fee) == 0){
  $discount_granted = true; 
  $discount_factor = 1;
}else{

	$row = mysqli_fetch_array($first_fee);
	$prev_balance_remaining = $row['balance_remaining'];


}



if($package_name == "1 Month"){
	$expire_datetime = date('Y-m-d H:i:s', strtotime("+1 months", strtotime($confirmed_datetime)));
		if($discount_granted){
			$balance_remaining = $discount_factor*1500 - $balance_paid;
		}else{
			$balance_remaining = 1500 - $balance_paid;
		}
}else if($package_name == "4 Months"){
	$expire_datetime = date('Y-m-d H:i:s', strtotime("+4 months", strtotime($confirmed_datetime)));
		if($discount_granted){
			$balance_remaining = $discount_factor*4500 - $balance_paid;
		}else{
			$balance_remaining = 4500 - $balance_paid;
		}
}else if($package_name == "6 Months"){
	$expire_datetime = date('Y-m-d H:i:s', strtotime("+6 months", strtotime($confirmed_datetime)));
		if($discount_granted){
			$balance_remaining = $discount_factor*6000 - $balance_paid;
		}else{
			$balance_remaining = 6000 - $balance_paid;
		}
}else if($package_name == "12 Months"){
	$expire_datetime = date('Y-m-d H:i:s', strtotime("+12 months", strtotime($confirmed_datetime)));
		if($discount_granted){
			$balance_remaining = $discount_factor*9000 - $balance_paid;
		}else{
			$balance_remaining = 9000 - $balance_paid;
		}
}

$balance_remaining += $prev_balance_remaining;


$confirm_payment = "UPDATE my_fee SET status='1', 
 admin_id='$approver',expire_datetime='$expire_datetime'
 ,confirmed_datetime='$confirmed_datetime',balance_remaining = '$balance_remaining'
 WHERE fee_id=$fee_id";

$confirm_payment = mysqli_query($conn, $confirm_payment) or die(mysqli_error($conn));

echo "Payment Confirmed <a href=\"..\home.php\">Click here</a> to go back";


?>