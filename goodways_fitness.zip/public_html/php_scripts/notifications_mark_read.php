<?php 

require('../includes/common.php');
include('../includes/is_auth.php');
header("Content-Type: application/json; charset=UTF-8");

$email = $_SESSION['email'];
$datetime = date('Y-m-d H:i:s');

if($_POST['notifications_id'] != Null){

	$notifications_id = $_POST['notifications_id'];

	$query = "UPDATE notifications set status = 1,read_datetime = '$datetime' 
	where notifications_id = $notifications_id and email = '$email'";

	mysqli_query($conn, $query) or die(mysqli_error($conn));

	echo "read marked";

}



?>



