<?php
include('../includes/common.php');
include('../includes/is_auth.php');

if(!isset($_SESSION['id'])){
	header('location: ../index.php');
	
}else{
    if($_SESSION['Isadmin'] == true){
        header('location: index.php');
    }
}

$member_id = $_SESSION['id'];
echo $member_id;

$query = "DELETE from account_deletion where member_id='$member_id'";

mysqli_query($conn, $query) or die(mysqli_error($conn));

echo "deletion is cancelled";

header('location: ../settings.php');
exit();

?>