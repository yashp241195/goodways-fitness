<?php
include('../includes/common.php');
include('../includes/is_auth.php');



$update_submit = isset($_POST['update_submit']);
$delete_submit = isset($_POST['delete_submit']);

$gender = $_SESSION['gender'];

if($_FILES['file_profile_image']["tmp_name"] == Null){
    if($gender == "female"){
        $file_profile_image = file_get_contents('../images/profile-default-female.jpg');
    }else{
        $file_profile_image = file_get_contents('../images/profile-default-male.jpg');
    }
	
}else{
	$file_profile_image = file_get_contents($_FILES['file_profile_image']["tmp_name"]);
}



$profile_image = base64_encode($file_profile_image);

$uid = $_SESSION['id'];
$col_value = $profile_image;	

	if($_SESSION['Isadmin'] == true){
        $update_cmd = "UPDATE admin_users SET profile_pic='$col_value' WHERE admin_id = $uid";
    }
    else{
        $update_cmd = "UPDATE member_users SET profile_pic='$col_value' WHERE member_id = $uid";
    }
    
    $user_registration_submit = mysqli_query($conn, $update_cmd) or die("error");

    echo 'updated';
 
// echo '<img src="data:image;base64,'.$profile_image.' " 
// width="250" height="250" alt="profile pic" class="img thumbnail" >';


	header('location: ..\home.php');
	exit();



?>