<?php

	
require('includes/common.php');
include('includes/header.php');

if(!isset($_SESSION['email'])){
	header('location: index.php');
	
}else{
    if($_SESSION['Isadmin'] == true){
        header('location: index.php');
    }
}

$id = $_SESSION['id'];

$select_query = "SELECT * from account_deletion 
where status = -1 and member_id='$id'";

$select_query_result = mysqli_query($conn,$select_query)or die(mysqli_error($conn));
$result = mysqli_num_rows($select_query_result);

$account_deletionActive = false;

if($result > 0){
    $account_deletionActive = true;
}

?>

<div class="container">
    <div class="row">
        <div class="col-md-10 ">

            <form class="form-horizontal" method="post" action="php_scripts/change_settings.php">
                <fieldset>

                    <!-- Form Name -->
                    <legend>Password Reset</legend>

                    <!-- Text input-->

                    <div class="form-group">
                        <label class="col-md-4 control-label" for="old_password">Old Password</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user">
                                    </i>
                                </div>
                                <input id="old_password" name="old_password" type="password" placeholder="Old Password" class="form-control input-md" required>
                            </div>


                        </div>


                    </div>

                    <div class="form-group">
                        <label class="col-md-4 control-label" for="new_password">New Password</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user">
                                    </i>
                                </div>
                                <input id="new_password" name="new_password" type="password" placeholder="New Password" class="form-control input-md" required>
                            </div>


                        </div>


                    </div>

                    <div class="form-group">
                        <label class="col-md-4 control-label" for="confirm_new_password">Re-Enter New Password</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user"></i>
                                </div>
                                <input id="confirm_new_password" name="confirm_new_password" type="password" placeholder="Re-Enter New Password" class="form-control input-md" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-4 control-label" for="confirm_new_password"></label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <div id="hint_text">
                                </div>                                
                            </div>
                        </div>
                    </div>



                    <div class="form-group">
                        <label class="col-md-4 control-label" ></label>
                        <div class="col-md-4">
                            
                            <input type="submit" name="update_password" onclick="return confirm_password()" 
                            class="btn btn-success" value="Update Password" >

                            <a href="#" onclick="reset_form()" class="btn btn-danger" value="">
                            <span class="glyphicon glyphicon-remove-sign"></span> Clear All</a>

                        </div>
                    </div>

                </fieldset>
            </form>

<script type="text/javascript">
    
function confirm_password() {

    var z = document.forms[0]["old_password"].value;
    var x = document.forms[0]["new_password"].value;
    var y = document.forms[0]["confirm_new_password"].value;

    if(z == "" || x == "" || z == ""){
        document.getElementById("hint_text").innerHTML ="unable to submit empty";
        return false;
    }

    if(z == x || z == y){
            document.getElementById("hint_text").innerHTML ="Old can't be new password";
            return false;
        }
    
    if (x != y) {
        document.getElementById("hint_text").innerHTML ="re enter password correctly";
        return false;
    }
   

    return true;
}

function reset_form(){
    document.forms[0]["old_password"].value = "";
    document.forms[0]["new_password"].value = "";
    document.forms[0]["confirm_new_password"].value = "";
    document.getElementById("hint_text").innerHTML = "";

}


</script>
     
        <form class="form-horizontal" action="php_scripts/change_settings.php" method="post">
            <fieldset>
            
            <?php if($account_deletionActive == false){ ?>
            <!-- Form Name -->
            <legend>Account Deletion</legend>

            <!-- Text input-->
                
            <div class="form-group">
                <label class="col-md-4 control-label" for="current_password">Current Password</label>
                <div class="col-md-4">
                    <div class="input-group">
                        <div class="input-group-addon">
                            <i class="fa fa-user">
                            </i>
                        </div>
                        <input id="current_password" name="current_password" type="password" placeholder="Current Password" class="form-control input-md" required>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" for="re_current_password">Re-Enter Current Password</label>
                <div class="col-md-4">
                    <div class="input-group">
                        <div class="input-group-addon">
                            <i class="fa fa-user">
                            </i>
                        </div>
                        <input id="re_current_password" name="re_current_password" type="password" placeholder="Re-Enter Current Password" class="form-control input-md" required>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label" ></label>
                <div class="col-md-4">
                    <div id="hint_text_2"></div>
                    <br>
                    <input type="submit" onclick="return deletion_validate()" name="request_deletion" class="btn btn-danger"
                     value="Request Deletion" >
                    <a href="#" onclick="reset_form2()" class="btn btn-success" value=""><span class="glyphicon glyphicon-remove-sign"></span> Cancel</a>
                    
                </div>
            </div>

            <?php }else{
                
                echo "<legend>Account Deletion is scheduled</legend>";
                
                $button = '<div class="form-group">
                        <label class="col-md-4 control-label" ></label>
                        <div class="col-md-4">
                        <a href="php_scripts/cancel_account_deletion.php" class="btn btn-success" value="">
                            <span class="glyphicon glyphicon-remove-sign"></span>
                         Cancel Account Deletion</a>
                        </div>';   

                echo "$button";


                } ?>

                

            </fieldset>
        </form>
        </div>

    </div>
</div>
    
<script type="text/javascript">
    
    function deletion_validate(){
        
        var x = document.forms[1]["re_current_password"].value;
        var y = document.forms[1]["current_password"].value;

        if(x == "" || y == ""){

            document.getElementById("hint_text_2").innerHTML ="flelds are empty";
            return false;
        }

        if(x != y){
            document.getElementById("hint_text_2").innerHTML ="Please re enter password again correctly";
            return false;
        }
        return true;

    }

    function reset_form2(){
        document.forms[1]["re_current_password"].value = "";
        document.forms[1]["current_password"].value = "";
        document.getElementById("hint_text_2").innerHTML = "";

    }

</script>



<?php
include('includes/footer.php');

?>

	
</body>
</html>