<?php
require('includes/common.php');
include('includes/is_auth.php');

include('includes/header.php');


?>



        <div class="container">
            <div  class="panel panel-default panel-table" style="overflow-x:auto;">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col col-xs-6">
                            <h3 class="panel-title"><b id="my_fee_heading"> Fee </b></h3>
                        </div>
                        <div class="col col-xs-6 text-right">
                            <button onclick="location.reload()" 
                            class=" btn btn-sm btn-success glyphicon glyphicon-refresh"></button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col col-xs-12">
                            <br><br><br>
                        </div>
                        
                    </div>
                </div>

                <div class="panel-body">
                    <table style="font-size:12px;" 
                    class="table table-striped table-bordered table-list">
                        
            
                        <thead>
                            <tr>
                                <th>S No</th>
                                <th>Member Name </th>
                                <th>Member Email </th>
                                <th>Requested Date </th>
                                <th>Requested Time </th>
                                <th>Confirm Date </th>
                                <th>Confirm Time </th>
                                <th>Confirmed by </th>
                                <th>Position</th>
                                <th>Email</th>
                                <th>Package </th>
                                <th>Expire Date</th>
                                <th>Amount Paid</th>
                                <th>Remaining</th>
                                
                            </tr>
                        </thead>

                        <tbody id="my_fee_rows">
                        </tbody>
                
                    </table>
                </div>
        <div class="panel-footer">
            <div class="row">
                <div class="col col-xs-4" id="my_fee_page_no">
                    <p>Page 1 of 10</p>
                </div>

                <div class="col col-xs-8">
                    <ul id="my_fee_pagination" class="pagination hidden-xs pull-right">
                    </ul>
                </div>
            </div>
        </div>
    
    </div>
</div>


<script type="text/javascript">
    

    var page_count = 1;


    function set_table_page_limit(table_name,value){

        switch(table_name){

            case "my_fee":                
                page_count = value;
                break;

            
            }

    }

    function get_table_page_limit(table_name){

        switch(table_name){

            case "my_fee":                
                return page_count;

            }
            
    }

    function get_table_data(t_name, page_no){

        var row_limit_per_page = 20;

        var xmlhttp = new XMLHttpRequest();

        // always put address of the page where function is called
        // here ../ajax_php/is_email_available.php does not work

        xmlhttp.open("POST", "ajax_php/display_rows_fee.php", true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xmlhttp.onreadystatechange = function() {

                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                    var row_item = document.getElementById(t_name+"_rows"); 
                    var pagination = document.getElementById(t_name+"_page_no");
                    var heading = document.getElementById(t_name+"_heading");

                                       
                    
                    var recieve = JSON.parse(xmlhttp.responseText);

                    row_item.innerHTML = recieve[0];
                    page_max_limit = parseInt(recieve[1]/row_limit_per_page)+1;

                    set_table_page_limit(t_name,page_max_limit);

                    pagination.innerText = "Page "+page_no+" of "+page_max_limit;

                    heading.innerText = recieve[2];
                    
                    
                }
            };

            xmlhttp.send('page_no='+page_no+'&row_limit='+row_limit_per_page);

    }

    function pageination(t_name, pg=1){

        if(pg < 1){
            pg = 1;
        }

        var page_limit = get_table_page_limit(t_name);

        // console.log(page_limit);

        if(pg > page_limit){
            return 0;
        }

        var total_pg = 4;

        pg_before = (pg - total_pg);
        pg_after = (pg + total_pg);

        if((page_limit/total_pg) < 1){
            pg_after = page_limit;
        }
        
        var text = "<li><a href=\"#\" onclick=\"pageination('"+t_name+"',"+pg_before+")\">«</a></li>";
        
        for (var i = pg; i <= pg_after; i++) {
            text += "<li><a href=\"#\" onclick=\"get_table_data('"+t_name+"',"+i+")\">"+i+"</a></li>";
        }

        text += "<li><a href=\"#\" onclick=\"pageination('"+t_name+"',"+pg_after+")\">»</a></li>";

        var pagination_view = document.getElementById(t_name+"_pagination");
        pagination_view.innerHTML = text;


    }


    get_table_data("my_fee",1);
    pageination('my_fee');



</script>


<br />
<br />
<br />
<br />
<br />
<br />


<?php
include('includes/footer.php');
?>
