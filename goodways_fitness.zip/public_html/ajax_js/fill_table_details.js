    
    // Define each column with it's property in the array
    // col_name, col_type, col_width, col_text_suffix, col_value

    var body_measurements = [

            ["date","date","140","",""],
            ["height","number","70","cm",""],
            ["weight","number","70","kg",""],
            ["upper_abs","number","70","inch",""],
            ["middle_abs","number","70","inch",""],
            ["lower_abs","number","70","inch",""],
            ["hips","number","70","inch",""],
            ["thighs","number","70","inch",""],
            ["left_arm","number","70","inch",""],
            ["right_arm","number","70","inch",""],
        ];

    var body_scanning = [
            ["date","date","140","",""],
            ["body_fat","number","70"," % ",""],
            ["metabolic_age","number","70"," years",""],
            ["bmi","number","70"," ",""],
            ["bmr","number","70"," ",""],
            ["visceral_fat","number","70"," % ",""],
            ["subcutaneous_fat","number","70"," % ",""],
            ["skeletal_muscle","number","70"," % ",""],
        ];

    var scientific_test = [
            ["date","date","140","",""],
            ["cardio_test","text","70","",""],
            ["strength_test","text","70","",""],
            ["endurance_test","text","70","",""],
            ["rpr_test","text","70","",""],
            ["flexiblity_test","text","70","",""],
            ["lungs_capacity","text","70","",""],
            ["stress_test","text","70","",""],
            ["skin_fold","text","70","",""],
            ["psychological_test","text","70","",""],
        ];

    var health_background = [
            ["date","date","140","",""],
            ["doctor_name","text","70","",""],
            ["doctor_phone","text","70","",""],
            ["bp","text","70","",""],
            ["pulse","text","70","",""],
            ["health_issues","text","70","",""],
            ["reasons","text","70","",""],
            ["medicines","text","70","",""],
            ["health_advice","text","70","",""],            
            ["goals","text","70","",""],
        ];    

    var workout_schedule = [
            ["date","date","140","",""],
            ["email","email","50","","1"],
            ["exercise_name","text","100","",""],
            ["sets","number","60","",""],
            ["reps_current","number","70","",""],
            ["reps_target","number","70","",""],            
            ["exercise_category","text","100","",""],
            ["body_area","text","100","",""],
            ["remarks","text","100","",""],             
        ];



    // 


    var col_count_bm = col_count_bs = col_count_st = col_count_hb = col_count_ws = 1;

    var col_max_count_bm = body_measurements.length;
    var col_max_count_bs = body_scanning.length;
    var col_max_count_st = scientific_test.length;
    var col_max_count_ws = workout_schedule.length;
    var col_max_count_hb = health_background.length;


    function col_count_change(table_name,sign_value=0){

        switch(table_name){

            case "body_measurements":                
                col_count_bm += sign_value;
                break;

            case "body_scanning":                
                col_count_bs += sign_value;
                break;

            case "scientific_test":                
                col_count_st += sign_value;
                break;

            case "health_background":
                col_count_hb += sign_value;
                break;

            case "workout_schedule":                
                col_count_ws += sign_value;
                break;



        }

    }


    function get_col_count_array(table_name){

        switch(table_name){

            case "body_measurements":
                col_count = col_count_bm;
                col_max_count = col_max_count_bm;
                break;

            case "body_scanning":
                col_count = col_count_bs;
                col_max_count = col_max_count_bs;
                break;

            case "scientific_test":
                col_count = col_count_st;
                col_max_count = col_max_count_st;
                break;

            case "health_background":
                col_count = col_count_hb;
                col_max_count = col_max_count_hb;
                break;

            case "workout_schedule":
                col_count = col_count_ws;
                col_max_count = col_max_count_ws;
                break;
        }

        return [col_count,col_max_count];

    }


    function get_col_property_array(table_name,column_no){

        var i = column_no;

        switch(table_name){

                case "body_measurements":
                    col_name = body_measurements[i][0];
                    col_type = body_measurements[i][1];
                    col_width = body_measurements[i][2];
                    col_text_suffix = body_measurements[i][3];
                    col_value = body_measurements[i][4];
                    break;

                case "body_scanning":
                    col_name = body_scanning[i][0];
                    col_type = body_scanning[i][1];
                    col_width = body_scanning[i][2];
                    col_text_suffix = body_scanning[i][3];
                    col_value = body_scanning[i][4];
                    break;

                case "scientific_test":
                    col_name = scientific_test[i][0];
                    col_type = scientific_test[i][1];
                    col_width = scientific_test[i][2];
                    col_text_suffix = scientific_test[i][3];
                    col_value = scientific_test[i][4];
                    break;

                case "health_background":
                    col_name = health_background[i][0];
                    col_type = health_background[i][1];
                    col_width = health_background[i][2];
                    col_text_suffix = health_background[i][3];
                    col_value = health_background[i][4];
                    break;

                case "workout_schedule":
                    col_name = workout_schedule[i][0];
                    col_type = workout_schedule[i][1];
                    col_width = workout_schedule[i][2];
                    col_text_suffix = workout_schedule[i][3];
                    col_value = workout_schedule[i][4];
                    break;
        }

        return [col_name, col_type, col_width, col_text_suffix, col_value];

    }

/*
    Please don't touch the code below
*/
        
    function insert_row(table_name){
                
        table = document.getElementById(table_name);

        var array = [];
        array = get_col_count_array(table_name);
        
        var col_count = array[0];
        var col_max_count = array[1];
        
        var row = table.insertRow(col_count);
                
        for (var i = 0; i < col_max_count; i++) {

            var column_property_array = [];
            column_property_array = get_col_property_array(table_name,i);

            col_name = column_property_array[0];
            col_type = column_property_array[1];
            col_width = column_property_array[2];
            col_text_suffix = column_property_array[3];
            col_value = column_property_array[4];

            row.insertCell(i).innerHTML = "<input"+ " name='"+col_name+
            "' type='"+ col_type+"' "+"value='"+col_value+"' "+
            "class='input-sm' style='height:25px; width:"+col_width+"px;' >"
            +col_text_suffix;

        }

        var del_str = "<a class='glyphicon glyphicon-trash btn btn-xs btn-danger' ";
        del_str += "onclick= \"delete_row("+col_count+",'"+table_name+"')\">Delete</a>";

        var save_str = "<a class='glyphicon glyphicon-save btn btn-xs btn-success' ";
        save_str += "onclick= \"save_row("+col_count+",'"+table_name+"')\">Save</a>";

        row.insertCell(col_max_count).innerHTML ="<div><div class='row'>"+
        "<div class='col-xs-12'>"+save_str+"</div><div class='col-xs-12'>"+
        del_str+"</div></div></div>";

        // increment count
        col_count_change(table_name,1);


    }


    function delete_row(j,table_name) {

      document.getElementById(table_name).deleteRow(j);
      
      // decrement count
      col_count_change(table_name,-1);
      
    }


    function delete_row_db(j,table_name) {

        var xmlhttp = new XMLHttpRequest();

        xmlhttp.open("POST", "ajax_php/delete_row.php", true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var table_row_action = document.getElementById(table_name+"_row_"+j).parentElement;
                // delete button does not exist in edit_row, table updatation 
                if(table_row_action != null){
                    table_row_action.innerHTML =  xmlhttp.responseText;
                }                 
                console.log(xmlhttp.responseText);
            }
        };
        
        var t_name = JSON.stringify(table_name);
        var t_id = JSON.stringify(j);

        xmlhttp.send('t_id='+j+'&t_name='+t_name);
      
    }


    function save_row(j,table_name){

        var table = document.getElementById(table_name);

        var content = table.rows[j].cells;

        // accessing each cell

        cell_values = [];
        cell_col_names = [];

        var max_count = content.length-1;

        for (var i = 0; i < max_count; i++) {
            
            var my_value = content[i].firstElementChild.value;
            var my_name = content[i].firstElementChild.name;
                
            cell_values.push(my_value);
            cell_col_names.push(my_name);

            var column_property_array = [];

            column_property_array = get_col_property_array(table_name,i);
            col_text_suffix = column_property_array[3];
           
            var units = String(col_text_suffix);

            content[i].innerHTML = ""+my_value+" "+units;
            
        }


        var arr_vals = JSON.stringify(cell_values);
        var arr_names = JSON.stringify(cell_col_names);
        var t_name = JSON.stringify(table_name);

        console.log(t_name,arr_vals,arr_names);


        var xmlhttp = new XMLHttpRequest();

        xmlhttp.open("POST", "ajax_php/insert_row.php", true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.onreadystatechange = function() {

            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var status = content[content.length-1]; 
                status.innerHTML =  xmlhttp.responseText;
                console.log(xmlhttp.responseText);
            }
        
        };

        xmlhttp.send('arr_vals='+arr_vals+'&arr_names='+arr_names+'&t_name='+t_name);


    }


    function edit_row(j,table_name){

        var table = document.getElementById(table_name);
        var table_edit_row_action = document.getElementById(table_name+"_edit_row_"+j).parentElement; 

        var row = table_edit_row_action.parentElement;
        var row_Index = row.rowIndex;

        var content = row.cells;
        var max_count = content.length - 1;
        var string = "";

        // console.log(max_count);

        for (var i = 0; i < max_count; i++) {


            var column_property_array = [];
            column_property_array = get_col_property_array(table_name,i);

            col_name = column_property_array[0];
            col_type = column_property_array[1];
            col_width = column_property_array[2];
            col_text_suffix = column_property_array[3];
            
            col_value = content[i].textContent;
    
            if(col_type == "number"){
                col_value = parseFloat(col_value);
            }
            if(col_type == "date"){
                
                col_value = String(col_value);
                mystr = col_value.split("-");
                finalstr = mystr[2]+"-"+mystr[1]+"-"+mystr[0];
                col_value = String(finalstr);
                // "2012-12-12";
            }


            if(table_name == "workout_schedule"){


            }

                        
            col_string = "<td><input"+ " name='"+col_name+
            "' type='"+ col_type+"' "+"value='"+col_value+"' "+
            "class='input-sm' style='height:25px; width:"+col_width+"px;' >"
            +col_text_suffix+"</td>";

            string += col_string;

            console.log(col_value+" \n "+col_string);
        
        }


        var save_str = "<a class='glyphicon glyphicon-save btn btn-xs btn-warning' ";
        save_str += "onclick= \"update_row("+j+","+row_Index+",'"+table_name+"') \">update</a>";

        string += "<td> "+"<div><div class='row'><div class='col-xs-12'>"+save_str+
        "</div><div class='col-xs-12'></div></div></div></td>";

        row.innerHTML= string;


    }


    function update_row(j,row_Index,table_name){

        save_row(row_Index,table_name);
        delete_row_db(j,table_name);

    }



    function refresh_table(){
        window.location.reload(true);
    }
      

/* 
    code not to Touch End here 

*/        

    function insert_multiple_rows(table_name,num){

            if(table_name == "workout_schedule"){

                var chk = document.getElementById("chk_available");
                // console.log(chk.textContent);
                if(chk.textContent != "Email already exists"){
                
                return 0;

            }


            var email = document.getElementById("email_id").value;
            console.log("email : "+email);
            workout_schedule[1][4] = email;
                
            var date = document.getElementById("date_ws").value;
            workout_schedule[0][4] = String(date);
            console.log("date : "+date);

            var exercise_category_ws = document.getElementById("exercise_category_ws");
            var e = exercise_category_ws;
            opt = e.options[e.selectedIndex].text;
            workout_schedule[6][4] = opt;

            if(num<=1){
                insert_row(table_name);
                return 0;
            }

            limit = 0;
            switch(opt){
            
            	case "Basic Ex.": 
            
                var my_rows = [ 
            
            		// exercise name,sets,body area
            
            			["Figure 8","3","Lower Abs"],			        
            			["Figure C","3","Lower Abs"],			   
            			["Both Leg Cycling","3","Lower Abs"],	    
            			["Open Leg 60° Leg Raise","3","Lower Abs"],
            			["Standing Leg Side","3","Lower Abs"],
            			["4 Crunch","3","Middle Abs"],
            			["V Sit Ups","3","Middle Abs"],
            			["Plank Moving","3","Middle Abs"],
            			["Titanic Side Bend","3","Middle Abs"],
            			["Kick to Lunge","3","Hip and Thighs"],
            			["Side Lunge","3","Hip and Thighs"],
            			["Y Curl","3","Hip and Thighs"],
            			["Donkey Kick","3","Hip and Thighs"]
            
            		];
            		
            		limit = my_rows.length;
            
            	break;
            
            	
            
            	case "Neck Pain": 
            	        	
            		var my_rows = [ 
            			        
            			// exercise name,sets,body area
            	            
            			["Figure 8","3","Lower Abs"],
            			["Figure C","3","Lower Abs"], 
            			["Both Leg Cycling","3","Lower Abs"],	    
            			["Open Leg 60° Leg Raise","3","Lower Abs"],
            			["Standing Leg Side","3","Lower Abs"],
            			["4 Crunch","3","Middle Abs"],
            			["V Sit Ups","3","Middle Abs"],
            			["Plank Moving","3","Middle Abs"],
            			["Titanic Side Bend","3","Middle Abs"],
            			["Kick to Lunge","3","Hip and Thighs"],
            			["Side Lunge","3","Hip and Thighs"],
            			["Y Curl","3","Hip and Thighs"],
            			["Donkey Kick","3","Hip and Thighs"]
            
            		];
                    
                    limit = my_rows.length;
            			        
            	break;
            
            
                    
            	case "Back Pain": 
            		            
            		var my_rows = [ 
            			              
            		// exercise name,sets,body area			  
            
            			["Reverse Sit ups","3","Lower Abs"],
            			["Single Leg up","3","Lower Abs"], 
            			["Pawanmuktasan","3","Lower Abs"], 
            			["Bhujangasan","3","Lower Abs"],
            			["Standing Leg Side","3","Lower Abs"],
            			["4 Crunch","3","Middle Abs"],
            			["V Sit Ups","3","Middle Abs"],
            			["Plank Knee Touch","3","Middle Abs"],
            			["Titanic Side Bend","3","Middle Abs"],
            			["Kick to Lunge","3","Hip and Thighs"],
            			["Side Lunge","3","Hip and Thighs"],
            			["Y Curl","3","Hip and Thighs"],
            			["Donkey Kick","3","Hip and Thighs"]
            			          
            		 ];
            		 
            		 limit = my_rows.length;
            
            	break;
            
                    
            
            	case "Knee Pain": 
            		            
            		var my_rows = [ 
            		              
            			// exercise name,sets,body area
            
            			["Figure 8","3","Lower Abs"],
            			["Figure C","3","Lower Abs"], 
            			["Both Leg Cycling","3","Lower Abs"],
            			["Open Leg 60° Leg Raise","3","Lower Abs"],
            			["Standing Leg Side","3","Lower Abs"],
            			["4 Crunch","3","Middle Abs"],
            			["V Sit Ups","3","Middle Abs"],
            			["Plank Moving","3","Middle Abs"],
            			["Titanic Side Bend","3","Middle Abs"],
            			["L Shape","3","Hip and Thighs"],
            			["Leg Open Close","3","Hip and Thighs"],
            			["Knee Stretching","3","Hip and Thighs"],
            			["Basic Kick","3","Hip and Thighs"]
            		  
            		];
            		
            		limit = my_rows.length;
            
            		        
            	break;
            	
            	case "Functional Basic": 
            	    
                    var my_rows = [ 
            
            		// exercise name,sets,body area
            
            			["Stepper R-L High Knee","0","Functional"],			        
            			["Stepper Run","0","Functional"],			   
            			["Stepper R-L Toe Touch","0","Functional"],	    
            			["Stepper Front Hop","0","Functional"],
            			["Standing Leg Side","0","Functional"],
            			["Stepper Basic Jumping Jack","0","Functional"]
            			
            
            		];
            		
            		limit = my_rows.length;
            
            	    break;
            	
            	case "Functional Back Pain": 
            
                    var my_rows = [ 
                
                		// exercise name,sets,body area
                
                			["Open Leg High Knee R-L","0","Functional"],			        
                			["V Run","0","Functional"],			   
                			["Knee Repeater","0","Functional"],	    
                			["Back Pain Ex.","0","Functional"],
                			["Back Pain Ex.","0","Functional"]
                			
                
                		];
                		
                		limit = my_rows.length;
                		
            
            	    break;

       	
            	case "Functional Knee Pain": 
            
                    var my_rows = [ 
                
                		    // exercise name,sets,body area
                
                			["Open Leg High Knee R-L","0","Functional"],			        
                			["V Run","0","Functional"],			   
                			["Knee Repeater","0","Functional"],	    
                			["Knee Pain Ex.","0","Functional"],
                			["Knee Pain Ex.","0","Functional"]
                			
                		];
                		
                		limit = my_rows.length;
                		 
                
                	break;
            	
            	
            
               }
            
            
            

             for(i=0; i<limit; i++){

                workout_schedule[2][4] = String(my_rows[i][0]);
                workout_schedule[3][4] = String(my_rows[i][1]);
                workout_schedule[7][4] = String(my_rows[i][2]);
                
                insert_row(table_name);
            
                workout_schedule[2][4] = "";
                workout_schedule[3][4] = "";
                workout_schedule[7][4] = "";
            }
            

        }else{

             for(i=0; i<num; i++){
                insert_row(table_name);
            }


        }





       

                

    }


    
