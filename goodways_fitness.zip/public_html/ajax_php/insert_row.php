<?php
include('../includes/common.php');
include('../includes/is_auth.php');

header("Content-Type: application/json; charset=UTF-8");

if ($_POST['arr_vals'] != Null && $_POST['arr_names'] != Null && $_POST['t_name'] != Null) {


    $arr_vals = json_decode($_POST["arr_vals"]);
	$arr_names = json_decode($_POST["arr_names"]);
    $table_name = json_decode($_POST['t_name']);

	$uid = $_SESSION['id'];
    
    $insert_cmd = "insert into ".$table_name."(";

    if($_SESSION['Isadmin']){
        $args = "admin_id,";
        $vals = "'".$uid."',";  
    }else{
        $args = "user_id,";
        $vals = "'".$uid."',";
    }
    

    $max_size = sizeof($arr_vals);

    for ($i = 0; $i < $max_size; $i++) { 

        // special logic for workout table

        if($table_name == "workout_schedule"){

            if($arr_names[$i] == "email"){
                
                $Isadmin = $_SESSION['Isadmin'];

                if($Isadmin){
                    $my_query = "SELECT member_id from member_users where email = '$arr_vals[$i]'";
                    
                    $query_submit = mysqli_query($conn, $my_query) 
                    or die(mysqli_error($conn));

                    $row = mysqli_fetch_array($query_submit);
                    $user_id = $row['member_id'];

                    $args .= "user_id";
                    $vals .= "'".mysqli_real_escape_string($conn,$user_id)."'";
                    
                    $args .=",";
                    $vals .=",";

                }else{

                    $email = $_SESSION['email'];
                    $args .= "email";
                    $vals .= "'".mysqli_real_escape_string($conn,$email)."'";
                    
                    $args .=",";
                    $vals .=",";

                    continue;

                }

                
            }

            

            if($arr_names[$i] == "reps_target"){

                if($arr_vals[$i] == 0 or $arr_vals[$i] == ""){

                    // cases according to exercise category

                    $p = array_search("body_area",$arr_names);
                    $body_area = $arr_vals[$p];
                    
                    $factor = 1.15;

                    switch($body_area){

                        case "Neck Pain": 
                            // 15% increment of reps_target
                            $factor = 1.15; 
                            break;
                        case "Back Pain": 
                            // 15% increment of reps_target
                            $factor = 1.15; 
                            break;
                        case "Knee Pain": 
                            // 15% increment of reps_target
                            $factor = 1.15; 
                            break;
                        case "Basic Ex.": 
                            // 15% increment of reps_target
                            $factor = 1.15; 
                            break;
                        case "Functional Basic": 
                            // 15% increment of reps_target
                            $factor = 1.15; 
                            break;
                        case "Functional Back Pain": 
                            // 15% increment of reps_target
                            $factor = 1.15; 
                            break;
                        case "Functional Knee Pain": 
                            // 15% increment of reps_target
                            $factor = 1.15; 
                            break;

                    }


                    $p = array_search("reps_current",$arr_names);
                    $arr_vals[$i] = (string)($factor*$arr_vals[$p]);

                }

            }

        }
        

    	$args .= $arr_names[$i];
    	$vals .= "'".mysqli_real_escape_string($conn,$arr_vals[$i])."'";


    	if($i < $max_size - 1){
    		$args .=",";
    		$vals .=",";

    	}

    }

    $insert_cmd .= $args.")values(".$vals.")";


    $table_submit = mysqli_query($conn, $insert_cmd) or die(
	mysqli_error($conn)
	);

    echo 'row inserted';

} 
else {
    echo 'Invalid parameters!';
}

?>