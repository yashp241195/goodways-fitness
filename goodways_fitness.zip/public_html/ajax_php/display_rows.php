<?php 

include('../includes/common.php');
include('../includes/is_auth.php');
header("Content-Type: application/json; charset=UTF-8");

$Isadmin = $_SESSION['Isadmin'];

if($_POST['t_name'] != Null && $_POST['page_no'] != Null && $_POST['row_limit'] != Null){
	
	$t_name = $_POST['t_name'];
	$page_no = $_POST['page_no'];
	$row_limit = $_POST['row_limit'];

	$offset = ($page_no-1)*$row_limit;

	$total_row_count = 0;

	$all_row = "";	


	if($t_name == "body_measurements"){

		 // Body Measurements - latest

		if($Isadmin==true){

			// count rows

			$count_query = "SELECT COUNT(body_measurements_id) from body_measurements inner join member_users on 
			body_measurements.user_id=member_users.member_id";

			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(body_measurements_id)'];

			// fetch rows with limit

			$query = "SELECT * from body_measurements inner join member_users on 
			body_measurements.user_id=member_users.member_id ORDER BY date DESC LIMIT $offset,$row_limit";

			$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$body_measurements = $user_query;

		}else{

			$uid = $_SESSION['id'];	

			// count rows

			$count_query = "SELECT COUNT(body_measurements_id) from body_measurements WHERE user_id = $uid";			
			
			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(body_measurements_id)'];

			// fetch rows with limit

			$query = "SELECT * from body_measurements WHERE user_id = $uid ORDER BY date DESC LIMIT $offset,$row_limit";

			$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$body_measurements = $user_query;

		}

    
		
		

		while ($row = mysqli_fetch_array($body_measurements)){

		    $body_measurements_id = $row['body_measurements_id'];		    
		    $date = date_format(date_create($row['date']), 'd-m-Y');
		    $height = $row['height']." cm ";
		    $weight = $row['weight']." kg ";
		    $upper_abs = $row['upper_abs']." inch ";
		    $middle_abs = $row['middle_abs']." inch ";
		    $lower_abs = $row['lower_abs']." inch ";
		    $hips = $row['hips']." inch ";
		    $thighs = $row['thighs']." inch ";
		    $left_arm = $row['left_arm']." inch ";
		    $right_arm = $row['right_arm']." inch ";

		    $delete = "<a id=\"body_measurements_row_$body_measurements_id\" onclick='delete_row_db($body_measurements_id,\"body_measurements\")' class=\"glyphicon glyphicon-trash btn btn-xs btn-danger
		    \">Delete</a>";

		    $edit = "<a id=\"body_measurements_edit_row_$body_measurements_id\" 
		    onclick='edit_row($body_measurements_id,\"body_measurements\")' 
		    class=\"glyphicon glyphicon-pencil btn btn-xs btn-primary
		    \">Edit</a>";

			    if($Isadmin){

			        $email = $row['email'];
			    
			        $display_row = "<tr><td>$date</td><td>$email</td><td>$height</td>".
			        "<td>$weight</td><td>$upper_abs</td><td>$middle_abs</td>".
			        "<td>$lower_abs</td><td>$hips</td><td>$thighs</td>".
			        "<td>$left_arm</td><td>$right_arm</td></tr>";

			    }else{
			    
			        $display_row = "<tr><td>$date</td><td>$height</td>".
			        "<td>$weight</td><td>$upper_abs</td><td>$middle_abs</td>".
			        "<td>$lower_abs</td><td>$hips</td><td>$thighs</td>".
			        "<td>$left_arm</td><td>$right_arm</td><td>$edit $delete</td></tr>";


			    }
				 
		    
		    $all_row .= $display_row;

		}

	}


	if($t_name == "body_scanning"){

		// Body Scanning - latest

		if($Isadmin==true){

			// count rows

			$count_query = "SELECT COUNT(body_scanning_id) from body_scanning inner join member_users on 
			body_scanning.user_id=member_users.member_id";

			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(body_scanning_id)'];

			// fetch rows with limit

    		$query = "SELECT * from body_scanning inner join member_users on 
    		body_scanning.user_id=member_users.member_id ORDER BY date DESC LIMIT $offset,$row_limit";

    		$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$body_scanning = $user_query;


		}else{

			$uid = $_SESSION['id'];

			// count rows

			$count_query = "SELECT COUNT(body_scanning_id) from body_scanning WHERE user_id = $uid";			
			
			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(body_scanning_id)'];

			// fetch rows with limit
				
			$query = "SELECT * from body_scanning WHERE user_id = $uid ORDER BY date DESC LIMIT $offset,$row_limit";

			$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$body_scanning = $user_query;		

		}

    
		

		

		while ($row = mysqli_fetch_array($body_scanning)){
                           
            $body_scanning_id = $row['body_scanning_id'];

            $date = date_format(date_create($row['date']), 'd-m-Y');
            $body_fat = $row['body_fat']." % ";
            $metabolic_age = $row['metabolic_age']." years ";
            $bmi = $row['bmi']." ";
            $bmr = $row['bmr']." ";
            $visceral_fat = $row['visceral_fat']." % ";
            $subcutaneous_fat = $row['subcutaneous_fat']." % ";
            $skeletal_muscle = $row['skeletal_muscle']." % ";
                                 
                                    
            $delete = "<a id=\"body_scanning_row_$body_scanning_id\" onclick='delete_row_db($body_scanning_id,\"body_scanning\")' class=\"glyphicon glyphicon-trash btn btn-xs btn-danger
            \">Delete</a>";

            $edit = "<a id=\"body_scanning_edit_row_$body_scanning_id\" 
		    onclick='edit_row($body_scanning_id,\"body_scanning\")' 
		    class=\"glyphicon glyphicon-pencil btn btn-xs btn-primary
		    \">Edit</a>";

                if($Isadmin){

                    $email = $row['email'];

                    $display_row = "<tr><td>$date</td><td>$email</td><td>$body_fat</td>".
                "<td>$metabolic_age</td><td>$bmi</td><td>$bmr</td>".
                "<td>$visceral_fat</td><td>$subcutaneous_fat</td><td>$skeletal_muscle</td>".
                "</tr>";


                }else{

                    $display_row = "<tr><td>$date</td><td>$body_fat</td>".
                "<td>$metabolic_age</td><td>$bmi</td><td>$bmr</td>".
                "<td>$visceral_fat</td><td>$subcutaneous_fat</td><td>$skeletal_muscle</td>".
                "<td>$edit $delete</td></tr>";

                }
             
                              
            $all_row .= $display_row;

        }


	}

	if($t_name == "scientific_test"){

		// scientific_test - latest

		if($Isadmin==true){

			// count rows

			$count_query = "SELECT COUNT(scientific_test_id) from scientific_test inner join member_users on 
			scientific_test.user_id=member_users.member_id";

			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(scientific_test_id)'];

			// fetch rows with limit

    		$query = "SELECT * from scientific_test inner join member_users on 
    		scientific_test.user_id=member_users.member_id ORDER BY date DESC LIMIT $offset,$row_limit";

    		$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$scientific_test = $user_query;


		}else{

			$uid = $_SESSION['id'];	
			
			// count rows

			$count_query = "SELECT COUNT(scientific_test_id) from scientific_test WHERE user_id = $uid";			
			
			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(scientific_test_id)'];
			
			// fetch rows with limit

    		$query = "SELECT * from scientific_test WHERE user_id = $uid ORDER BY date DESC LIMIT $offset,$row_limit";

    		$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$scientific_test = $user_query;

		}

 		

		while ($row = mysqli_fetch_array($scientific_test)){
                               
            $scientific_test_id = $row['scientific_test_id'];

            $date = date_format(date_create($row['date']), 'd-m-Y');
            $cardio_test = $row['cardio_test']." ";
            $strength_test = $row['strength_test']." ";
            $endurance_test = $row['endurance_test']." ";
            $rpr_test = $row['rpr_test']." ";
            $flexiblity_test = $row['flexiblity_test']." ";
            $lungs_capacity = $row['lungs_capacity']." ";
            $stress_test = $row['stress_test']." ";
            $skin_fold = $row['skin_fold']." ";
            $psychological_test = $row['psychological_test']." ";
                                        
                                        
            $delete = "<a id=\"scientific_test_row_$scientific_test_id\" onclick='delete_row_db($scientific_test_id,\"scientific_test\")' class=\"glyphicon glyphicon-trash btn btn-xs btn-danger
            \">Delete</a>";

            $edit = "<a id=\"scientific_test_edit_row_$scientific_test_id\" 
		    onclick='edit_row($scientific_test_id,\"scientific_test\")' 
		    class=\"glyphicon glyphicon-pencil btn btn-xs btn-primary
		    \">Edit</a>";

            if($Isadmin){
                $email = $row['email'];

            $display_row = "<tr><td>$date</td><td>$email</td><td>$cardio_test</td>".
            "<td>$strength_test</td><td>$endurance_test</td><td>$rpr_test</td>".
            "<td>$flexiblity_test</td><td>$lungs_capacity</td><td>$stress_test</td>".
            "<td>$skin_fold</td><td>$psychological_test</td></tr>";


            }else{

            $display_row = "<tr><td>$date</td><td>$cardio_test</td>".
            "<td>$strength_test</td><td>$endurance_test</td><td>$rpr_test</td>".
            "<td>$flexiblity_test</td><td>$lungs_capacity</td><td>$stress_test</td>".
            "<td>$skin_fold</td><td>$psychological_test</td><td>$edit $delete</td></tr>";

            }

         	$all_row .= $display_row;
            

        }


	}

	if($t_name == "health_background"){

		// health_background - latest

		if($Isadmin==true){

			// count rows

			$count_query = "SELECT COUNT(health_background_id) from health_background inner join member_users on 
			health_background.user_id=member_users.member_id";

			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(health_background_id)'];

			// fetch rows with limit

    		$query = "SELECT * from health_background inner join member_users on 
    		health_background.user_id=member_users.member_id ORDER BY date DESC LIMIT $offset,$row_limit";

    		$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$health_background = $user_query;


		}else{

			$uid = $_SESSION['id'];	
			
			// count rows

			$count_query = "SELECT COUNT(health_background_id) from health_background WHERE user_id = $uid";			
			
			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(health_background_id)'];
			
			// fetch rows with limit

    		$query = "SELECT * from health_background WHERE user_id = $uid ORDER BY date DESC LIMIT $offset,$row_limit";

    		$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$health_background = $user_query;

		}

		
		while ($row = mysqli_fetch_array($health_background)){
                               
            $health_background_id = $row['health_background_id'];
            $date = date_format(date_create($row['date']), 'd-m-Y');
            $doctor_name = $row['doctor_name']." ";
            $doctor_phone = $row['doctor_phone']." ";
            $bp = $row['bp']." ";
            $pulse = $row['pulse']." ";
            $health_issues = $row['health_issues']." ";
            $reasons = $row['reasons']." ";
            $medicines = $row['medicines']." ";
            $health_advice = $row['health_advice']." ";
            $goals = $row['goals']." ";
                                        
                                        
            $delete = "<a id=\"health_background_row_$health_background_id\" 
            onclick='delete_row_db($health_background_id,\"health_background\")' 
            class=\"glyphicon glyphicon-trash btn btn-xs btn-danger\">Delete</a>";

            $edit = "<a id=\"health_background_edit_row_$health_background_id\" 
		    onclick='edit_row($health_background_id,\"health_background\")' 
		    class=\"glyphicon glyphicon-pencil btn btn-xs btn-primary\">Edit</a>";

            if($Isadmin){
                $email = $row['email'];

            $display_row = "<tr><td>$date</td><td>$email</td><td>$doctor_name</td>".
            "<td>$doctor_phone</td><td>$bp</td><td>$pulse</td>".
            "<td>$health_issues</td><td>$reasons</td><td>$medicines</td>".
            "<td>$health_advice</td><td>$goals</td></tr>";


            }else{

            $display_row = "<tr><td>$date</td><td>$doctor_name</td>".
            "<td>$doctor_phone</td><td>$bp</td><td>$pulse</td>".
            "<td>$health_issues</td><td>$reasons</td><td>$medicines</td>".
            "<td>$health_advice</td><td>$goals</td><td>$edit $delete</td></tr>";

            }

         	$all_row .= $display_row;
            

        }


	}


	if($t_name == "workout_schedule"){

		// workout_schedule - latest

		if($Isadmin==true){
			// count rows

			$count_query = "SELECT COUNT(workout_schedule_id) from workout_schedule inner join member_users on workout_schedule.user_id=member_users.member_id where admin_id = 0";

			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(workout_schedule_id)'];

			// fetch rows with limit


    		$query = "SELECT * from workout_schedule inner join member_users on 
    		workout_schedule.user_id=member_users.member_id where admin_id = 0 ORDER BY date DESC LIMIT $offset,$row_limit";

    		$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$workout_schedule = $user_query;


		}else{

			$uid = $_SESSION['id'];

			// count rows

			$count_query = "SELECT COUNT(workout_schedule_id) from workout_schedule WHERE user_id = $uid";			
			
			$count_query = mysqli_query($conn, $count_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($count_query);

			$total_row_count = $row['COUNT(workout_schedule_id)'];

			// fetch rows with limit
				
			$query = "SELECT * from workout_schedule WHERE user_id = $uid ORDER BY date DESC LIMIT $offset,$row_limit";

			$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
			$workout_schedule = $user_query;

		}

    
		$num = 1;

		while ($row = mysqli_fetch_array($workout_schedule)){
                               
            $workout_schedule_id = $row['workout_schedule_id'];
            
            $date = date_format(date_create($row['date']), 'd-m-Y');
            $exercise_name = $row['exercise_name']." ";
            $sets = $row['sets']." ";
            $reps_current = $row['reps_current']." ";
            $reps_target = $row['reps_target']." ";
            $body_area = $row['body_area']." ";
            $exercise_category = $row['exercise_category']." ";
            $remarks = $row['remarks']." ";
                                        
                                        
            $delete = "<a id=\"workout_schedule_row_$workout_schedule_id\" onclick='delete_row_db($workout_schedule_id,\"workout_schedule\")' class=\"glyphicon glyphicon-trash btn btn-xs btn-danger
            \">Delete</a>";

            $edit = "<a id=\"workout_schedule_edit_row_$workout_schedule_id\" 
		    onclick='edit_row($workout_schedule_id,\"workout_schedule\")' 
		    class=\"glyphicon glyphicon-pencil btn btn-xs btn-primary
		    \">Edit</a>";
			
			$approve = "<a id=\"workout_schedule_edit_row_$workout_schedule_id\" 
		    onclick='edit_row($workout_schedule_id,\"workout_schedule\")' 
		    class=\"glyphicon glyphicon-pencil btn btn-xs btn-primary
		    \">Approve</a>";

            if($Isadmin){
                
	            $email = $row['email'];

	            $display_row = "<tr><td>$date</td><td>$email</td><td>$exercise_name</td>
	            <td>$sets</td><td>$reps_current</td>
	            <td>$reps_target</td><td>$exercise_category</td><td>$body_area</td><td>$remarks</td><td>$approve $delete</td></tr>";

            }
            else{
				
				$email = $_SESSION['email'];

	            $display_row = "<tr><td>$date</td><td>$email</td><td>$exercise_name</td>
	            <td>$sets</td><td>$reps_current</td><td>$reps_target</td>
	            <td>$exercise_category</td><td>$body_area</td><td>$remarks</td><td>$edit $delete</td></tr>";

            }

            $all_row .= $display_row;
            
            $num += 1;

        }

	}
	
	$my_array = array($all_row,$total_row_count);
	
	echo json_encode($my_array);


}

?>