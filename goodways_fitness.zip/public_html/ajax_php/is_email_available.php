<?php 

include('../includes/common.php');
header("Content-Type: application/json; charset=UTF-8");


if ($_POST['email'] != Null && $_POST['user_type'] !=Null){

    $email = $_POST["email"];
    $user_type = $_POST["user_type"];

    if($user_type == "admin"){

    	$query = "SELECT * from admin_users where admin_email = '$email'";
    	$answer = mysqli_query($conn, $query) or die(mysqli_error($conn));

    }else{

    	$query = "SELECT * from member_users where email = '$email'";
    	$answer = mysqli_query($conn, $query) or die(mysqli_error($conn));
    }

	
    if(mysqli_num_rows($answer) == 0){
    	// testing
    	// echo "available in $user_type";
    	echo "Available, Email does not exists";
    }else{
    	// testing
    	// echo "not available in $user_type";
    	echo "Email already exists";
    }

	
}



?>