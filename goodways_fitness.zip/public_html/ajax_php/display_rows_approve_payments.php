<?php

include('../includes/common.php');
include('../includes/is_auth.php');
header("Content-Type: application/json; charset=UTF-8");

$Isadmin = $_SESSION['Isadmin'];

if($_POST['page_no'] != Null && $_POST['row_limit'] != Null){
	
	$page_no = $_POST['page_no'];
	$row_limit = $_POST['row_limit'];

	$offset = ($page_no-1) * $row_limit;
	$total_row_count = 0;

	$all_row = "";	

		if($Isadmin){

			// Display Fee - latest


			$select_query = "SELECT COUNT(fee_id) from my_fee inner join 
		    member_users on member_users.member_id = my_fee.member_id inner join 
		    admin_users on my_fee.admin_id = admin_users.admin_id
		    where my_fee.status = -1";

			$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
			$row = mysqli_fetch_array($select_query_result);

			$total_row_count = $row['COUNT(fee_id)'];

			$select_query = "SELECT * from my_fee inner join 
			member_users on member_users.member_id = my_fee.member_id 
			where my_fee.status = -1 ORDER BY confirmed_datetime DESC LIMIT $offset,$row_limit";

			$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
			$my_fee = $select_query_result;


		}

		$s_num = 1;
        // fetch query result row wise 

        while ($row = mysqli_fetch_array($my_fee)){

            $fee_id = $row['fee_id'];
            $member_name = $row['member_name'];

            $reqested_date = date_format(date_create($row['requested_datetime']), 'd-m-Y');
            $reqested_time = date_format(date_create($row['requested_datetime']), 'H:i:s');
            
            $email_id = $row['email'];
            
            $balance_paid = $row['balance_paid'];
            $balance_remaining = $row['balance_remaining'];
            $package = $row['package']; 

            $confirm = "<a class=\"glyphicon glyphicon-ok btn btn-xs btn-success\" onclick=\"accept_fee($fee_id,'row_$s_num')\">Confirm</a>";
			
			$reject = "<a class=\"glyphicon glyphicon-trash btn btn-xs btn-danger\" onclick=\"reject_fee($fee_id,'row_$s_num')\">Reject</a>";

            $display_content = "<tr ><td>$s_num</td><td>$member_name</td><td>$email_id</td>
            <td>$reqested_date</td><td>$reqested_time</td><td>Rs $balance_paid</td><td>$package</td>
            <td id=\"row_$s_num\">$confirm $reject</td></tr>";   



	        $all_row .= $display_content; 


	        $s_num++; 
	    } 

	    $my_array = array($all_row,$total_row_count);
		echo json_encode($my_array);
	

}


?>