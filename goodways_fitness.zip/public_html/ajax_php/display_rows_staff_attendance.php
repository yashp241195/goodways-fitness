<?php

include('../includes/common.php');
include('../includes/is_auth.php');
header("Content-Type: application/json; charset=UTF-8");

$Isadmin = $_SESSION['Isadmin'];

if($_POST['page_no'] != Null && $_POST['row_limit'] != Null){
    
    $page_no = $_POST['page_no'];
    $row_limit = $_POST['row_limit'];

    $offset = ($page_no-1) * $row_limit;
    $total_row_count = 0;

    $heading = "Staff Attendance";

    $all_row = "";  

    if($Isadmin){

        // Display Fee - latest

        $uid = $_SESSION['id'];

        $heading = "Staff Attendance (You)";

        $select_query = "SELECT COUNT(staff_attendance_id) from staff_attendance inner join 
        admin_users on staff_attendance.user_id = admin_users.admin_id 
        where user_id = $uid ORDER BY exit_datetime DESC";

        $select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
        $row = mysqli_fetch_array($select_query_result);

        $total_row_count = $row['COUNT(staff_attendance_id)'];

        $select_query = "SELECT * from staff_attendance inner join 
        admin_users on staff_attendance.user_id = admin_users.admin_id 
        where user_id = $uid ORDER BY exit_datetime DESC LIMIT $offset,$row_limit";

        $select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
        $staff_attendance = $select_query_result;


    }else{


        // Display Fee - latest

        $heading = "All Staff Attendance";

        $select_query = "SELECT COUNT(staff_attendance_id) from staff_attendance inner join 
        admin_users on staff_attendance.user_id = admin_users.admin_id
        ORDER BY exit_datetime DESC";

        $select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
        $row = mysqli_fetch_array($select_query_result);

        $total_row_count = $row['COUNT(staff_attendance_id)'];

        $select_query = "SELECT * from staff_attendance inner join 
        admin_users on staff_attendance.user_id = admin_users.admin_id
        ORDER BY exit_datetime DESC LIMIT $offset,$row_limit";

        $select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
        $staff_attendance = $select_query_result;


    }

        // fetch query result row wise 
        $s_num = 1;

        while ($row = mysqli_fetch_array($staff_attendance)){
                    
            $member_name = $row['admin_name'];
            $email = $row['admin_email'];
              
            $entry_date = date_format(date_create($row['entry_datetime']), 'd-m-Y');
            $entry_time = date_format(date_create($row['entry_datetime']), 'H:i:s');
            $exit_time = date_format(date_create($row['exit_datetime']), 'H:i:s');

            $display_row = "<tr><td>$s_num</td><td>$member_name</td><td>$email</td>
            <td>Present</td><td>$entry_date</td><td>$entry_time</td><td>$exit_time</td>
            </tr>";

            $all_row .= $display_row;
            $s_num++; 

        }

        $my_array = array($all_row,$total_row_count,$heading);
        echo json_encode($my_array);
        

}


?>