<?php 

include('includes/common.php');
include('includes/is_auth.php');
include('includes/header.php');


$uid = $_SESSION['id'];


$query = "SELECT * from workout_schedule where user_id = '$uid' and admin_id > 0 ORDER BY date DESC,body_area desc,exercise_category desc";

$user_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
$workout_schedule = $user_query;

$all_row = "";

$body_area_array = array();

?>

<div class="container">
	<div  class="panel panel-default panel-table" style="overflow-x:auto;">
	    <div class="panel-heading">
	        <div class="row">
	            <div class="col col-xs-6">
	                <h3 class="panel-title"><b>Workout Schedule</b></h3>
	            </div>
	            <div class="col col-xs-6 text-right">
	                <button onclick="location.reload()" class=" btn btn-sm btn-success glyphicon glyphicon-refresh"></button>
	            </div>
	        </div>
	        <div class="row">
	            <div class="col col-xs-12">
	                <br><br><br>
	            </div>
	            
	        </div>
	    </div>

		<div class="panel-body">
			<table  id = "workout_schedule" style="font-size:12px;" 
			class="table table-striped table-bordered table-list">
		        
		        <tbody>
	                            
						<?php



						$prev_body_area = "";

						while ($row = mysqli_fetch_array($workout_schedule)){

						    $workout_schedule_id = $row['workout_schedule_id'];
						    
						    $date = date_format(date_create($row['date']), 'd-m-Y');
						    $exercise_name = $row['exercise_name']." ";
						    $reps_current = $row['reps_current']." ";
						    $reps_target = $row['reps_target']." ";
							$sets = $row['sets']." ";

						    $exercise_category = $row['exercise_category']." ";
						    $remarks = $row['remarks']." ";
						    $body_area = $row['body_area'];


						    $display_row = "<tr><td>$exercise_name</td><td>$sets</td><td>$reps_current</td>
						    <td>$reps_target</td><td>$exercise_category</td><td>$remarks</td></tr>";

						    $all_row = $display_row;

							    if($body_area != $prev_body_area){

							    	if(in_array($body_area,$body_area_array)){

						    			break;
						    			// print_r($body_area_array);


							    	}else{
							    		array_push($body_area_array,$body_area);


							    	}	

							    	
							    	echo "<tr class=\"info\" ><td style=\"border:none\" ><b>Body Area</b></td>
							    	<td style=\"border:none\"> <b> $body_area </b></td>
							    	<td style=\"border:none\"></td><td style=\"border:none\"></td><td style=\"border:none\"><b>Date</b></td>
							    	<td style=\"border:none\"><b> $date </b> </td></tr>";
							    	
							    	echo "<tr class=\"warning\" ><th style=\"width: 200px; border:none\">Exercise Name </th>
							    		<th style=\"border:none\">Sets</th>
		                					<th style=\"border:none\">Reps Current</th><th style=\"border:none\">Reps Target</th>                                    
							                <th style=\"border:none\">Exercise Category</th><th style=\"border:none\">Remarks</th></tr>";

							        
							    }
						    		echo "$all_row";



					    		

						    	$prev_body_area = $body_area;

						    }


						?>
						
	            </tbody>
			</table>
		</div>
	    <div class="panel-footer">
	        <div class="row">
	            <div class="col col-xs-4" id="scientific_test_page_no">
	                <p>Daily Schedule</p>
	            </div>

	            <div class="col col-xs-8">
	                <ul id="scientific_test_pagination" class="pagination hidden-xs pull-right">
	                </ul>
	            </div>
	        </div>
	    </div>
	</div>
</div>



<?php
	include('includes/footer.php');
?>
