function confirm_password_signup() {

    var password = document.forms[0]["password"].value;
    var re_password = document.forms[0]["reenterpass"].value;

    if (password != re_password) {
        document.getElementById("hint_text").innerHTML ="re enter password correctly";
        return false;
    }
   

    return true;
}