function is_email_available(){

    var email = document.getElementById('email_id');    
    var chk_available = document.getElementById('chk_available');
    if(email.value == ""){
        chk_available.innerHTML = "Empty Input";
        return 0;
    }
    
    var xmlhttp = new XMLHttpRequest();
    
    // always put address of the page where function is called
    // here ../ajax_php/is_email_available.php does not work 

    xmlhttp.open("POST", "ajax_php/is_email_available.php", true);
    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            chk_available.innerHTML = xmlhttp.responseText;
            console.log(xmlhttp.responseText);
        }
    };
        
    var user_type = "member";
    var user_type_admin = document.getElementById('user_type_admin');
    var isadmin = false;

    if(user_type_admin != null){
        isadmin = user_type_admin.checked;
    }

    

    if(isadmin == true){
        user_type = "admin";
    }

    console.log(user_type);

    xmlhttp.send('email='+email.value+'&user_type='+user_type);


}
