    function edit_details(detail_id,detail_name,detail_value){
        
        var elem = document.getElementById(detail_id);

        if(detail_name=="gender"){

            elem.innerHTML = "<div class='col-xs-6'>"
            +"<select id='input_gender' name='gender' class=\"form-control input-sm\">"
            +"<option value=\"male\">Male</option>"
            +"<option value=\"female\" selected>Female</option>"
            +"</select>";
        
        }
        else if(detail_name=="blood_group"){
            
            elem.innerHTML = "<div class='col-xs-6'>"
            +"<select id='input_blood_group' name='blood_group' class=\"form-control input-sm\">"
            +"<option value=\"O-positive\">O-positive</option>"
            +"<option value=\"O-negative\">O-negative</option>"
            +"<option value=\"A-positive\">A-positive</option>"
            +"<option value=\"A-negative\">A-negative</option>"
            +"<option value=\"B-positive\">B-positive</option>"
            +"<option value=\"B-negative\">B-negative</option>"
            +"<option value=\"AB-positive\">AB-positive</option>"
            +"<option value=\"AB-negative\">AB-negative</option>"
            +"</select>";
        }
        else if(detail_name=="date_of_birth"){

            elem.innerHTML = "<div class='col-xs-6'><input class='form-control input-sm' type='date' name ='"+detail_name+"'"+" id='input_"+detail_name+"' value='"+detail_value+"' width='200' placeholder='"+detail_name+"' '>";

        }
        else{

        elem.innerHTML = 
        "<div class='col-xs-6'><input class='form-control input-sm' type='text' name ='"+detail_name+"'"+" id='input_"+
        detail_name+"' value='"+detail_value+"' width='200' placeholder='"+detail_name+"' '>";

        elem.innerHTML += "<a class='glyphicon glyphicon-remove btn btn-xs' "+ 
        " onclick='clear_txt(\"input_"+detail_name+"\")' >";
        
        }

        elem.innerHTML += "<input type='submit' onclick='update_details(\"input_"+detail_name+"\")'"+
        " class='btn btn-xs btn-primary' "+" value='save'></div>";

    }

    function clear_txt(detail_input_field_id){
        var elem = document.getElementById(detail_input_field_id);
        elem.classList.remove("show_error");
        elem.value = "";
    }

    function update_details(detail_input_field_id){

        var elem = document.getElementById(detail_input_field_id);

        var value = elem.value;
        var name = elem.name;

        console.log(name,value);
        
        if(value == ""){
            elem.classList.add("show_error");
            console.log("try again");
        }else{

                        
            console.log(name,value);

            var xmlhttp = new XMLHttpRequest();

            // always put address of the page where function is called
            // here ../ajax_php/is_email_available.php does not work

            xmlhttp.open("POST", "ajax_php/update_user_details.php", true);
            xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xmlhttp.onreadystatechange = function() {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                    var profile_item = elem.parentElement.parentElement; 
                    profile_item.innerHTML = value+" is "+xmlhttp.responseText;
                    
                    console.log(xmlhttp.responseText);
                }
            };
            
            var p_name = name;
            var p_value = value;
            console.log(p_name,p_value);


            xmlhttp.send('p_name='+p_name+'&p_value='+p_value);

        }


    }