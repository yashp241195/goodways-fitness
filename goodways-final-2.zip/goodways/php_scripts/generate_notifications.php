<?php 

require('../includes/common.php');
include('../includes/is_auth.php');


$Isadmin = $_SESSION['Isadmin'];

$date = date('Y-m-d H:i:s');
$deadline_date = date('Y-m-d H:i:s', strtotime("-3 days", strtotime($date)));
// echo "$date $deadline_date";
if($Isadmin){

	$admin_id = $_SESSION['id'];
		
	$select_query = "SELECT * from my_fee inner join member_users on member_users.member_id=my_fee.member_id 
	where expire_datetime between '$deadline_date' and '$date' ";

	$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
	$my_fee = $select_query_result;

	while ($row = mysqli_fetch_array($my_fee)){ 

		$email = $row['email'];
		$expire_datetime = $row['expire_datetime']; 
		$notifications_message = "Your subscription will end on $expire_datetime";
		
		$insert_notification = "INSERT INTO notifications(email,date,notifications_message,admin_id) values";
		$insert_notification .= "('$email','$date','$notifications_message','$admin_id')";
		$select_query_result = mysqli_query($conn,$insert_notification) or die(mysqli_error($conn));
	}


echo "<center>notifications Generated for $date <a href=\"..\home.php\">Click here</a> to go back </center>";


}

?>