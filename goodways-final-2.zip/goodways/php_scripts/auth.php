<?php 
require('../includes/common.php');

//Store form values into variables

$email = mysqli_real_escape_string($conn,$_POST['email']);
$acc_choice = mysqli_real_escape_string($conn,$_POST['opt_account']);
$password = mysqli_real_escape_string($conn,$_POST['password']);

// hack password command : { ' OR ''=' } mysqli_real_escape_string if not used

$Isadmin = false;

if($acc_choice == "admin"){
	$Isadmin = true;
}

// find the user in database

if($Isadmin == true){
	$user = "admin_users";
	$email_col = "admin_email";
}
else{
	$user = "member_users";
	$email_col = "email";
}


$user_auth_query = 
"SELECT * FROM ".$user." WHERE $email_col = '$email' AND password = '$password' ";

$mysqli_result = mysqli_query($conn, $user_auth_query) or die(mysqli_error($conn));

// if entry not found, go back to login page

if(mysqli_num_rows($mysqli_result) == 0){
	header('location: ..\index.php');
	exit();	 
}
else{
	
	// if entry found , fill your data into session variable

	$row = mysqli_fetch_array($mysqli_result);
    
    $_SESSION['Isadmin'] = $Isadmin;
    
    if($Isadmin == true){
    	$_SESSION['id'] = $row['admin_id'];
    	$_SESSION['email'] = $row['admin_email'];
    }else{
    	$_SESSION['id'] = $row['member_id'];
    	$_SESSION['email'] = $row['email'];
    }
    
 	header('location: ..\home.php');
	exit();
} 


?>