<?php

include('../includes/common.php');
include('../includes/is_auth.php');
header("Content-Type: application/json; charset=UTF-8");

$Isadmin = $_SESSION['Isadmin'];

if($_POST['page_no'] != Null && $_POST['row_limit'] != Null){
	
	$page_no = $_POST['page_no'];
	$row_limit = $_POST['row_limit'];

	$offset = ($page_no-1) * $row_limit;
	$total_row_count = 0;

	$heading = "Your Fee";

	$all_row = "";	

	if($Isadmin){

		// Display Fee - latest

		$heading = "All Members Fee";

		$select_query = "SELECT COUNT(fee_id) from my_fee inner join 
	    member_users on member_users.member_id = my_fee.member_id inner join 
	    admin_users on my_fee.admin_id = admin_users.admin_id
	    where my_fee.status <> -1 ";

		$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
		$row = mysqli_fetch_array($select_query_result);

		$total_row_count = $row['COUNT(fee_id)'];


	    $select_query = "SELECT * from my_fee inner join 
	    member_users on member_users.member_id = my_fee.member_id inner join 
	    admin_users on my_fee.admin_id = admin_users.admin_id
	    where my_fee.status <> -1 order by confirmed_datetime desc,
	    balance_remaining desc LIMIT $offset,$row_limit";

		$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
		$my_fee = $select_query_result;


	}else{


		// Display Fee - latest

		$uid = $_SESSION['id'];

		$select_query = "SELECT COUNT(fee_id) from my_fee inner join 
	    member_users on member_users.member_id = my_fee.member_id inner join 
	    admin_users on my_fee.admin_id = admin_users.admin_id
	    where member_users.member_id = $uid and my_fee.status <> -1 ";

		$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
		$row = mysqli_fetch_array($select_query_result);

		$total_row_count = $row['COUNT(fee_id)'];


	    $select_query = "SELECT * from my_fee inner join 
	    member_users on member_users.member_id = my_fee.member_id inner join 
	    admin_users on my_fee.admin_id = admin_users.admin_id
	    where member_users.member_id = $uid and my_fee.status <> -1 order by confirmed_datetime desc,
	    balance_remaining desc LIMIT $offset,$row_limit";

		$select_query_result = mysqli_query($conn,$select_query) or die(mysqli_error($conn));
		$my_fee = $select_query_result;

	}

	// fetch query result row wise 
    $s_num = 1;
    
    while ($row = mysqli_fetch_array($my_fee)){

        
        $member_name = $row['member_name'];

        $reqested_date = date_format(date_create($row['requested_datetime']), 'd-m-Y');
        $reqested_time = date_format(date_create($row['requested_datetime']), 'H:i:s');
        
        $confirm_date = date_format(date_create($row['confirmed_datetime']), 'd-m-Y');
        $confirm_time = date_format(date_create($row['confirmed_datetime']), 'H:i:s');

        $expire_date = date_format(date_create($row['expire_datetime']), 'd-m-Y');

        $email_id = $row['email'];
        $admin_email_id = $row['admin_email'];
        $admin_name = $row['admin_name'];
        $position = $row['position'];
        
        $balance_paid = $row['balance_paid'];
        $balance_remaining = $row['balance_remaining'];
        $package = $row['package'];   

        $display_row = "
        <tr>
            <td>$s_num</td><td>$member_name</td>
            <td>$email_id</td><td>$reqested_date</td>
            <td>$reqested_time</td><td>$confirm_date</td>
            <td>$confirm_time</td><td>$admin_name</td>
            <td>$position</td><td>$admin_email_id</td>
            <td>$package</td><td>$expire_date</td>
            <td>Rs $balance_paid</td><td>Rs $balance_remaining</td>
        </tr>";  

        $all_row .= $display_row; 


        $s_num++; 
    } 

    $my_array = array($all_row,$total_row_count,$heading);
	echo json_encode($my_array);
	

}


?>