<?php
include('../includes/common.php');

header("Content-Type: application/json; charset=UTF-8");

if ($_POST['p_value'] != Null && $_POST['p_name'] != Null) {


    $p_value = $_POST["p_value"];
	$p_name = $_POST["p_name"];

	$uid = $_SESSION['id'];

    $col_name = $p_name;
    $col_value = $p_value;



    if($_SESSION['Isadmin'] == true){
        if($col_name == "name"){
            $col_name = "admin_name";
        }
        $update_cmd = "UPDATE admin_users SET $col_name='$col_value' WHERE admin_id = $uid";
    }
    else{
        if($col_name == "name"){
            $col_name = "member_name";
        }
        $update_cmd = "UPDATE member_users SET $col_name='$col_value' WHERE member_id = $uid";
    }
    $user_registration_submit = mysqli_query($conn, $update_cmd) or die("error");

    echo 'updated';

} 
else {
    echo 'Invalid parameters!';
}

?>