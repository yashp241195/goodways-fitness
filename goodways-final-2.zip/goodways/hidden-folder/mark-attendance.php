<?php

require('../includes/common.php');

if(!(isset($_SESSION['email']))){
	header('location: ../index.php');
	exit();
}

$date = date('Y-m-d H:i:s');
$Isadmin = $_SESSION['Isadmin'];
$uid = $_SESSION['id'];
$position = "Member";

if ($Isadmin == true) {

  $query ="SELECT * from staff_attendance where user_id = '$uid' and exit_datetime = '$exit_datetime'";
  $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
  $row_p = mysqli_fetch_array($result);




  $query = "SELECT * from admin_users where admin_id = '$uid' and exit_datetime =  '$exit_datetime'";
  $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
  $row = mysqli_fetch_array($result);
  $name = $row['admin_name'];
  $position = $row['position'];
  $email = $row['admin_email'];

}else{

  $query ="SELECT * from staff_attendance where user_id = '$uid'";
  $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
  $row_p = mysqli_fetch_array($result);



  $query = "SELECT * from member_users where member_id = '$uid'";
  $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
  $row = mysqli_fetch_array($result);
  $name = $row['member_name'];
  $email = $row['email'];

}


?>
<html>
<head>
  <title>Goodways Fitness</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../css/index.css" rel="stylesheet" type="text/css" /> 
  <link href="../css/login_css.css" rel="stylesheet" type="text/css" /> 
  <link rel="stylesheet" type="text/css" href="../css/table.css">


</head>
<body>
<nav class="navbar navbar-fixed-top navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Goodways Fitness</a>
    </div>
    
  </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-md-10" >

            <form class="form-horizontal" method="post" action="upload-attendance.php">
                <fieldset>

                    <!-- Form Name -->
                    <legend>Mark Attendance</legend>

                    <!-- Text input-->

                    <div class="form-group">
                        <label class="col-md-4 control-label" >Member Name </label>
                        <label class="col-md-4 control-label" ><?php echo $name; ?></label>
                        
                    </div>

                    <div class="form-group">
                        <label class="col-md-4 control-label" >Account Type </label>
                        <label class="col-md-4 control-label" ><?php echo $position; ?></label>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-4 control-label" >Email id </label>
                        <label class="col-md-4 control-label" ><?php echo $email; ?></label>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-4 control-label" >Current Date Time </label>
                        <label class="col-md-4 control-label" ><?php echo $date; ?></label>
                        
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-4 control-label" for="confirm_new_password"></label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <div id="hint_text">
                                </div>                                
                            </div>
                        </div>
                    </div>



                    <div class="form-group">
                        <label class="col-md-4 control-label" ></label>
                        <div class="col-md-4">
                            
                            <input type="submit" name="update_password" onclick="return confirm_password()" 
                            class="btn btn-success" value="Mark Attendance" >

                            <a href="#" onclick="window.location.reload(true);" class="btn btn-primary" value="">
                            <span class="glyphicon glyphicon-refresh"></span> Refresh Page </a>

                        </div>
                    </div>

                </fieldset>
            </form>


     
        </div>

    </div>
</div>
    
<script type="text/javascript">
    
    function deletion_validate(){
        
        var x = document.forms[1]["re_current_password"].value;
        var y = document.forms[1]["current_password"].value;

        if(x == "" || y == ""){

            document.getElementById("hint_text_2").innerHTML ="flelds are empty";
            return false;
        }

        if(x != y){
            document.getElementById("hint_text_2").innerHTML ="Please re enter password again correctly";
            return false;
        }
        return true;

    }

    function reset_form2(){
        document.forms[1]["re_current_password"].value = "";
        document.forms[1]["current_password"].value = "";
        document.getElementById("hint_text_2").innerHTML = "";

    }

</script>




</body>
<?php

include('../includes/footer.php');

?>


