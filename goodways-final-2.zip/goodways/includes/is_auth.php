<?php

// if not logged-in then redirect

if (isset($_SESSION['id']) == false) {
	header('location: ../index.php');
	header('location: index.php');
	exit();
}

?>